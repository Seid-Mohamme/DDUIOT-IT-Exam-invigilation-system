/* MongoDB connection with serverless-safe caching.
   Required both by server/server.js (local/production long-running server)
   and api/index.js (Vercel serverless entry). Keeping the require inside the
   server/ folder guarantees `mongoose` resolves from server/node_modules no
   matter which entry point loads it. */
const mongoose = require('mongoose');

const MONGO_URI = process.env.MONGO_URI || 'mongodb://127.0.0.1:27017/invigilation_system';

/* On Vercel every warm lambda instance reuses one cached connection promise
   stored on globalThis instead of opening a new connection per invocation. */
const cached = global.__dduInvigMongo || (global.__dduInvigMongo = { promise: null });

function connectDB() {
  mongoose.set('strictQuery', true);
  if (!cached.promise) {
    cached.promise = mongoose
      .connect(MONGO_URI, { serverSelectionTimeoutMS: 8000 })
      .then(() => {
        console.log('[OK] MongoDB connected:', MONGO_URI);
        return mongoose;
      })
      .catch((err) => {
        cached.promise = null; // allow the next invocation to retry
        throw err;
      });
  }
  return cached.promise;
}

module.exports = { connectDB, MONGO_URI };
