/* =====================================================================
   DDU-IT Invigilation System - BACKEND entry point
   MongoDB: invigilation_system   |   API port: 5050
   Loads .env from this folder (see .env.example); on Vercel the environment
   variables come from the project dashboard instead.
   ===================================================================== */
require('dotenv').config();
const app = require('./src/app');
const { connectDB } = require('./src/config/database');

const PORT = process.env.PORT || 5050;

connectDB()
  .then(() => {
    app.listen(PORT, () =>
      console.log(`[OK] API server running -> http://localhost:${PORT}`));
  })
  .catch((e) => {
    console.error('[X] MongoDB connection failed:', e.message);
    console.error('    Start MongoDB first (net start MongoDB), then run: npm run dev');
    process.exit(1);
  });
