/* Vercel serverless entry point.
   Vercel turns every module inside the root `api/` folder into a serverless
   function; vercel.json rewrites every /api/* request to this one function.
   MongoDB is connected ONCE per warm lambda instance (the promise is cached
   in server/src/config/database.js) and the request is then handled by the
   full Express app. NOTE: mongoose is required from inside server/ (via the
   database module) so it always resolves from server/node_modules. */

const app = require('../server/src/app');
const { connectDB } = require('../server/src/config/database');

let ready = null; // cached connection promise

module.exports = async (req, res) => {
  try {
    if (!ready) ready = connectDB();
    await ready;
  } catch (err) {
    ready = null; // next invocation retries
    console.error('[api] DB connection failed:', err && err.message);
    /* plain-node compatible error reply (works on Vercel and locally) */
    res.statusCode = 500;
    res.setHeader('Content-Type', 'application/json');
    return res.end(JSON.stringify({
      ok: false,
      message: 'Database connection failed. On Vercel set MONGO_URI to a MongoDB Atlas connection string.'
    }));
  }
  return app(req, res);
};
