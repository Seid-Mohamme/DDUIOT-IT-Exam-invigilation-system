# DDU-IT Invigilation System

Invigilator assignment system based on the **mid / final exam schedule** and the list of **invigilators**.
Dire Dawa University - Institute of Technology.

Frontend and backend are fully separated, backed by a MongoDB database, with **login accounts for three roles**:

| Role | Who | Can do |
|---|---|---|
| **Admin** (Department Head) | main admin | everything: upload schedules, auto-assign, **fix wrong assignments**, reports, download all assignments as one Excel file, **share to Telegram**, and **manage all user accounts** |
| **Exam Coordinator** | departmental coordinator | manages exams, invigilators, assignments and reports (cannot manage user accounts) |
| **Invigilator** | departmental staff | login and view **their own assigned exams**: course, date, time, **room**, **batch**, role |

The logged-in user's role badge, name and the **Logout** button are always shown in the
**right corner of the navbar** (each displayed exactly once - the role badge shows
ADMIN / EXAM COORDINATOR / INVIGILATOR, so no text is ever repeated).

## Automatic logins for invigilators

Every invigilator you **add manually or upload from Excel/CSV automatically gets a
login account** - no extra step:

- **Email**: the invigilator's email if provided, otherwise generated from the Staff ID
  (e.g. `DDU/STF/2101` -> `ddu.stf.2101@ddu.edu.et`)
- **Default password**: `invig@123` - reset it any time in *User Accounts* or the Invigilators tab
- The toast after adding shows the created email; the *Login* column on the Invigilators page
  and the User Accounts list update automatically

## Absences, confirmations, reminders & feedback

**Recording an absence (Exam Coordinator / Department Head)** - on the *Assignments*
tab press **"Missed"** on the invigilator's chip:
- the whole department gets an **URGENT red banner** + notification: *replace this invigilator*
  (open **✨ Suggest** on that exam to find a free one) - if the Telegram bot is configured the
  alert is pushed to the department group too
- the record appears in **Absences & Feedback** with status *Open*

**The invigilator announces WHY they missed it** - on *My Exams* they see the record and press
**"Submit my reason"** (illness, official duty, ...). The reason goes to the coordinator and
Department Head as a notification.

**The Department Head takes the measure** - in *Absences & Feedback* press **"Take measure"**,
write the decision (warning letter, allowance deduction, ...). The record closes and the
invigilator is notified of the measure. **⬇ Download absence report** gives ONE Excel file
(all records + a summary per invigilator) for the department's files.

**Notifications (bell in the navbar, right corner)** - everyone sees a red unread badge:
- invigilators: **⏰ TODAY's exam reminders** (course, time, room), pending reason requests,
  measures taken on their absences
- Department Head / coordinator: absence alerts, reasons submitted, **✅ check-ins**
  ("I am in the exam room"), **🛡️ exam-running-safely confirmations**, new feedback

**Invigilator confirmations on My Exams** - for each exam session:
- **✅ I am in the exam room** - sent to the department instantly (badge "In room since 08:02")
- **🛡️ Exam is running safely** - confirmation that the exam is continuing safely

**Feedback** - invigilators press **💬 Give feedback** on any exam (General / Issue /
Suggestion / Other); the department reads everything in *Absences & Feedback*.

## User accounts (User Accounts tab - admin only)

The **Department Head** creates and manages every login from the **User Accounts** tab:

- **Create account** - pick the role (Admin / Exam Coordinator / Invigilator),
  enter email + password. For an invigilator login, select which staff member
  it belongs to - the system then shows them only their own exams.
- **Edit** - rename (e.g. fix an old name like "Department Head"), change the
  email, switch role, or re-link the invigilator.
- **Reset password** - set a new password for any account.
- **Disable / Enable** - a disabled account cannot sign in anymore.
- **Delete** - removes the login (the last active admin cannot be deleted,
  and you cannot delete, disable or demote the account you are logged in with).

## Structure

```
invigilation-system/
├── package.json            # root - one command runs everything
├── images/                 # static assets (served at site root)
│   └── logo.jpg            # official Dire Dawa University seal (replaceable)
├── client/                 # FRONTEND  (React + Vite)
│   ├── index.html
│   ├── vite.config.js      # dev server on port 5174, proxies /api -> server
│   └── src/
│       ├── main.jsx
│       ├── App.jsx         # login flow + role-based tabs
│       ├── index.css       # DDU theme (blue / gold)
│       ├── components/     # Toast, Modal, UploadModal (Excel/CSV import), ExamModal,
│       │                   # NotificationBell (navbar reminders & alerts)
│       ├── pages/          # Login, Dashboard, Exams, Invigilators, Assignments,
│       │                   # Reports (download + Telegram), MyExams (invigilator view:
│       │                   # today reminders, check-in, feedback), Incidents (absences
│       │                   # + feedback), Users (account management - admin only)
│       ├── services/       # api.js - adds the JWT token to every request
│       └── utils/          # helpers.js - Excel parsing, batches, date/time tools
├── server/                 # BACKEND  (Node + Express + MongoDB)
│   ├── server.js           # entry point (port 5050)
│   └── src/
│       ├── app.js          # express app + routes
│       ├── middleware/     # auth.js - JWT (requireAuth / requireAdmin / requireStaff)
│       ├── models/         # User, Exam (with batch), Invigilator, Assignment (check-in
│       │                   # fields), MissedInvigilation, Notification, Feedback, Setting
│       ├── controllers/    # request handlers (incl. auth + telegram)
│       ├── routes/         # /api/auth, /api/telegram, /api/exams, /api/invigilators,
│       │                   # /api/assignments, /api/stats, /api/sample
│       ├── services/       # assignmentService - auto-assign engine + clash checks
│       └── utils/          # timeUtils, batches (the 4 department batches)
└── database/
    └── seed/
        └── seed.js         # sample exams + invigilators + login accounts
```

## How to run

Prerequisite: **Node.js** and **MongoDB running** on your PC
(if not: open Command Prompt as Administrator and run `net start MongoDB`).

```bat
cd invigilation-system

:: 1. install everything (root + server + client)
npm run install-all

:: 2. load sample exams + invigilators + login accounts
npm run seed

:: 3. start backend (port 5050) + frontend (port 5174) together
npm run dev
```

Then open **http://localhost:5174** and login.

### Login accounts (after `npm run seed`)

| Account | Email | Password |
|---|---|---|
| Admin (Department Head) | `admin@ddu.edu.et` | `admin@123` |
| Exam Coordinator (demo) | `coordinator@ddu.edu.et` | `coord@123` |
| Invigilator (demo - Alemu Bekele) | `instructor@ddu.edu.et` | `invig@123` |

> Create more logins of any role in the **User Accounts** tab (admin only).
> Invigilator logins can also be created in the **Invigilators** tab -> "Invigilator logins".

## Production mode (optional)

```bat
npm run build --prefix client   :: creates client/dist
node server/server.js           :: backend now also serves the built frontend on port 5050
```

## Deploy to Vercel ✅ (deployment-ready, `.env` included)

The repository ships with everything Vercel needs — **one Vercel project serves both the React app and the API**:

- `vercel.json` — builds the client (`client/dist`), routes `/api/*` to the serverless function and everything else to the SPA (`index.html`), so refreshing *My Exams* or *Assignments* keeps working
- `api/index.js` — serverless entry point that connects MongoDB once per warm instance and delegates to the full Express app (`server/src/app.js`)
- `server/.env` — **ready-made environment file** for local use (demo defaults)
- `.env.example` — copy of the template

### Step-by-step

1. **Create a free MongoDB Atlas database** (M0 cluster is enough) — the local `127.0.0.1` MongoDB is **not reachable** from Vercel.
   - Database Access → add a user; Network Access → allow `0.0.0.0/0`;
   - copy the connection string: `mongodb+srv://<user>:<pass>@<cluster>.mongodb.net/invigilation_system`
2. **Push this repository to GitHub** (`.gitignore` excludes `node_modules` and `.env` — that is intentional; secrets never belong in Git).
3. On **vercel.com → Add New → Project** → import the repo. Vercel reads `vercel.json`; leave the build settings as detected.
4. Add **Environment Variables** (Project → Settings → Environment Variables) — the values from `server/.env`:

   | Variable     | Value                                       | Required |
   |--------------|---------------------------------------------|----------|
   | `MONGO_URI`  | your `mongodb+srv://…` Atlas URI            | ✔        |
   | `JWT_SECRET` | any long random string                      | ✔        |

5. **Deploy**. The app is live at `https://<project>.vercel.app` — health check: `https://<project>.vercel.app/api/health`.
6. **Load the demo data once** (optional, from your machine against Atlas):
   ```bash
   MONGO_URI="mongodb+srv://<user>:<pass>@<cluster>.mongodb.net/invigilation_system" npm run seed
   ```
7. (Optional) Custom domain: Project → Settings → Domains.

> **Notes**
> - The frontend calls the API with the relative base `/api`, so client and server always run on the same Vercel domain — no CORS or `VITE_API_URL` configuration needed.
> - Login tokens are JWTs stored in `localStorage`; no server-side sessions, so serverless scaling is safe.
> - Telegram report sharing works from Vercel (outbound HTTPS to `api.telegram.org`); the bot token is stored in the database via the *Telegram* tab, not in `.env`.
> - For **local production testing**: `npm run preview` (builds the client, then serves everything on port 5050).

## University logo

The official **Dire Dawa University seal** is at `images/logo.jpg`
(`invigilation-system/images/logo.jpg`) and appears in the top bar and on the
login screen. To swap it, just replace that file keeping the name `logo.jpg`.
Any image placed in `images/` is served from the site root, e.g.
`images/mypic.png` -> `/mypic.png`.

## Batches

Exams are tagged with one of the department's four batches
(select it in the exam form, or import a **Batch** column with your Excel file -
spellings like "IT 4th Year 2nd Sem." are recognised automatically):

- 2nd Year 1st Semester
- 3rd Year 1st Semester
- 4th Year 1st Semester
- 4th Year 2nd Semester

## How to use

1. Login as **Admin**.
2. **Exam Schedule** tab - add exams manually or **Upload Excel/CSV**
   (columns auto-detected: Course Code, Course Title, Section, Batch, Exam Type Mid/Final,
   Date, Start Time, End Time, Venue/Room, Students, Required Invigilators).
   A template file can be downloaded from the same page.
3. **Invigilators** tab - add staff manually or **Upload Excel/CSV**
   (Full Name, Staff ID, Department, Email, Phone, Max Load), then create a
   **login** for each invigilator who should see their own schedule.
4. Click **Auto-assign invigilators** - the engine fills every exam with the
   least-loaded, clash-free invigilators, respecting each person's max load,
   and **rotates the batches**: with equal load, the invigilator who covered
   that batch the fewest times wins, so every invigilator gets different
   batches on different exam days. The first person assigned to an exam
   becomes the **Instructor** (in-charge).
5. **Assignments** tab - fix anything wrong: **Change** replaces the invigilator
   or switches Instructor/Member, the status badge cycles
   Assigned -> Accepted -> Declined, and **Print** gives the timetable.
6. **Reports & Share** tab - filter by exam type / batch / search, then:
   - **Download Excel report** - ONE file with 3 sheets:
     *All Assignments*, *By Invigilator* (each person's load) and *Summary*.
   - **Send to Telegram** - push the same Excel file or a text summary to your
     department Telegram group (configure the bot once in Telegram settings).
   - **Open Telegram share** - share the summary without a bot.

## Conflict reminder & smart suggestions (Assignments tab)

- **Already assigned reminder** - every invigilator who is already booked at an
  exam's exact date & time is shown in the assign dropdown as
  `⚠ name - ALREADY ASSIGNED AT THIS TIME (course, date, time)` and is
  **blocked** (disabled), so a double-booking can never be saved. The backend
  rejects it too with the same clear message.
- **✨ Suggest** button on every exam opens a panel that:
  1. lists **✅ recommended invigilators** - free at this exam time, sorted by
     least load first, then by who covered this batch the fewest times
     (batch rotation);
  2. identifies the **overlapped** invigilators - each shows the clashing exam
     (course, date, time, room) AND the other exam sessions where that
     invigilator is still free (their free date & time), so you know exactly
     when they can be assigned instead.
- Each exam with overlaps also shows a yellow warning line listing who is
  double-booked at that time.

### One-time Telegram setup (admin)

1. In Telegram, message **@BotFather** -> `/newbot` -> copy the **bot token**.
2. Add the bot to your department **group** (or send it any message).
3. Open `https://api.telegram.org/bot<TOKEN>/getUpdates` in a browser and copy
   the **chat id** (`-100...` for groups).
4. In *Reports & Share* -> **Telegram settings**, paste both, **Save**,
   then **Send test message**. Done - now every report can be sent in one click.

## Terminology

- The role formerly called **Chief** is now **Instructor** (in-charge of the exam session).
- Positions to fill are described as **invigilator positions per total exams**
  (the word "slot" is no longer used).

## Troubleshooting

| Problem | Fix |
|---|---|
| `MongoDB connection failed: ECONNREFUSED` | Start MongoDB: `net start MongoDB` (as Administrator) |
| `Invalid email or password` on login | Run `npm run seed` (empty database), or create the account in the User Accounts tab |
| Name shows wrong / duplicated in the navbar | Rename the account in **User Accounts** -> Edit (the navbar shows the role badge + name once each) |
| An account cannot sign in | Check it is not **Disabled** in the User Accounts tab, then reset the password |
| Port 5050 / 5174 already in use | Close the other app using it, or change PORT in `server/server.js` / `client/vite.config.js` |
| Upload says "No rows found" | Make sure the FIRST ROW of the sheet contains the column headers |
| Some rows skipped on import | The exact reason is shown in the result message (e.g. missing course code, duplicate Staff ID) |
| Telegram: "chat not found" | Add the bot to the group / send it a message first, then re-check the chat id |
| An invigilator forgot their auto password | It is `invig@123` - or reset it in User Accounts |
| Absence recorded by mistake | Delete it in Absences & Feedback (Department Head only) |
| Telegram: "Unauthorized" | The bot token is wrong - copy it again from @BotFather |
| Old data shows no Batch | Re-import the schedule with a Batch column, or edit each exam and pick the batch |
