import * as XLSX from 'xlsx';

export const pad2 = (n) => String(n).padStart(2, '0');
export const toMin = (t) => { const [h, m] = String(t).split(':').map(Number); return h * 60 + m; };

export const fmtDate = (d) => new Date(d + 'T00:00:00').toLocaleDateString('en-GB',
  { weekday: 'short', day: 'numeric', month: 'short', year: 'numeric' });

export const fmtTime = (t) => {
  const [h, m] = t.split(':').map(Number);
  const ap = h >= 12 ? 'PM' : 'AM';
  const hh = h % 12 || 12;
  return `${hh}:${pad2(m)} ${ap}`;
};

/* ---- canonical student batches ---- */
export const BATCHES = [
  '2nd Year 1st Semester',
  '3rd Year 1st Semester',
  '4th Year 1st Semester',
  '4th Year 2nd Semester',
];

/* ---- Excel / CSV column matching ---- */
export const H = (s) => String(s || '').toLowerCase().replace(/[^a-z0-9]/g, '');
export const pick = (row, keys) => {
  for (const k of Object.keys(row)) if (keys.includes(H(k))) return row[k];
  return '';
};

export const EX_KEYS = {
  course: ['coursecode', 'code', 'course', 'courseno', 'coursenumber'],
  title: ['coursetitle', 'title', 'coursename', 'subject'],
  section: ['section', 'yearsection', 'group'],
  batch: ['batch', 'batchname', 'yearsemester', 'semester', 'yearandsemester', 'classbatch'],
  type: ['examtype', 'type', 'exam', 'category', 'semesterexam'],
  date: ['date', 'examdate', 'day', 'dateofexam'],
  start: ['starttime', 'start', 'from', 'begintime', 'begin', 'timein'],
  end: ['endtime', 'end', 'to', 'finishtime', 'finish', 'timeout'],
  venue: ['venue', 'room', 'hall', 'roomno', 'location', 'block'],
  students: ['students', 'studentscount', 'candidates', 'numberofstudents', 'strength'],
  required: ['requiredinvigilators', 'invigilators', 'required', 'numinvigilators', 'noofinvigilators', 'invigilatorsneeded'],
};
export const IN_KEYS = {
  name: ['name', 'fullname', 'invigilator', 'staffname', 'invigilatorname'],
  staffId: ['staffid', 'id', 'idno', 'staffno', 'employeeno', 'employeeid', 'idnumber'],
  department: ['department', 'dept', 'college', 'unit'],
  email: ['email', 'mail', 'emailaddress'],
  phone: ['phone', 'mobile', 'tel', 'telephone'],
  maxLoad: ['maxload', 'max', 'maxsessions', 'load'],
};

/* ---- read a spreadsheet into an array of row objects ---- */
export function parseFile(file) {
  return new Promise((resolve, reject) => {
    const fr = new FileReader();
    fr.onload = (e) => {
      try {
        const wb = XLSX.read(new Uint8Array(e.target.result), { type: 'array', cellDates: true });
        const ws = wb.Sheets[wb.SheetNames[0]];
        resolve(XLSX.utils.sheet_to_json(ws, { defval: '' }));
      } catch (err) {
        reject(new Error('Could not read the file. Use .xlsx or .csv'));
      }
    };
    fr.onerror = () => reject(new Error('Could not read the file'));
    fr.readAsArrayBuffer(file);
  });
}

/* ---- download a template spreadsheet ---- */
export function dlTemplate(kind) {
  const head = kind === 'exam'
    ? ['Course Code', 'Course Title', 'Section', 'Batch', 'Exam Type', 'Date', 'Start Time', 'End Time', 'Venue', 'Students', 'Required Invigilators']
    : ['Full Name', 'Staff ID', 'Department', 'Email', 'Phone', 'Max Load'];
  const rows = kind === 'exam'
    ? [['CSE2013', 'Data Structures', 'Sec-A', '2nd Year 1st Semester', 'Final', '2026-11-16', '8:00 AM', '10:00 AM', 'Room 201', 48, 2],
       ['MATH2011', 'Applied Mathematics I', 'Sec-B', '3rd Year 1st Semester', 'Mid', '2026-11-17', '8:00 AM', '9:30 AM', 'Hall A', 55, 2]]
    : [['Alemu Bekele', 'DDU/STF/2101', 'CSE', 'alemu@ddu.edu.et', '0911000001', 4],
       ['Hanna Tesfaye', 'DDU/STF/2102', 'ECE', 'hanna@ddu.edu.et', '0911000002', 4]];
  const wb = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(wb, XLSX.utils.aoa_to_sheet([head, ...rows]), 'Sheet1');
  XLSX.writeFile(wb, kind === 'exam' ? 'exam-schedule-template.xlsx' : 'invigilators-template.xlsx');
}
