import { useState } from 'react';
import Modal from './Modal.jsx';
import { BATCHES } from '../utils/helpers.js';

/* Add / edit an exam session */
export default function ExamModal({ exam, onClose, onSave }) {
  const [f, setF] = useState(exam ? {
    courseCode: exam.courseCode, courseTitle: exam.courseTitle || '', section: exam.section || '',
    batch: exam.batch || '',
    examType: exam.examType, date: exam.date, startTime: exam.startTime, endTime: exam.endTime,
    venue: exam.venue || '', studentsCount: exam.studentsCount || 0,
    requiredInvigilators: exam.requiredInvigilators || 1,
  } : {
    courseCode: '', courseTitle: '', section: '', batch: '', examType: 'Final', date: '',
    startTime: '08:00', endTime: '10:00', venue: '', studentsCount: '', requiredInvigilators: 1,
  });
  const set = (k) => (e) => setF({ ...f, [k]: e.target.value });
  const save = () => {
    if (!f.courseCode.trim() || !f.date) { alert('Course code and date are required'); return; }
    onSave(f);
  };
  return (
    <Modal title={exam ? 'Edit exam' : 'Add exam'} onClose={onClose}>
      <div className="fgrid">
        <div><label>Course code *</label><input type="text" value={f.courseCode} onChange={set('courseCode')} placeholder="CSE2013" /></div>
        <div><label>Course title</label><input type="text" value={f.courseTitle} onChange={set('courseTitle')} placeholder="Data Structures" /></div>
        <div><label>Section / Group</label><input type="text" value={f.section} onChange={set('section')} placeholder="Sec-A" /></div>
        <div><label>Batch</label>
          <select value={f.batch} onChange={set('batch')}>
            <option value="">- select batch -</option>
            {BATCHES.map((b) => <option key={b} value={b}>{b}</option>)}
          </select></div>
        <div><label>Exam type</label>
          <select value={f.examType} onChange={set('examType')}>
            <option>Mid</option><option>Final</option>
          </select></div>
        <div><label>Date *</label><input type="date" value={f.date} onChange={set('date')} /></div>
        <div><label>Venue / Room</label><input type="text" value={f.venue} onChange={set('venue')} placeholder="Room 201" /></div>
        <div><label>Start time</label><input type="time" value={f.startTime} onChange={set('startTime')} /></div>
        <div><label>End time</label><input type="time" value={f.endTime} onChange={set('endTime')} /></div>
        <div><label>Number of students</label><input type="number" min="0" value={f.studentsCount} onChange={set('studentsCount')} /></div>
        <div><label>Invigilators required</label><input type="number" min="1" max="10" value={f.requiredInvigilators} onChange={set('requiredInvigilators')} /></div>
      </div>
      <div className="mfoot">
        <button className="btn" onClick={onClose}>Cancel</button>
        <button className="btn primary" onClick={save}>{exam ? 'Save changes' : 'Add exam'}</button>
      </div>
    </Modal>
  );
}
