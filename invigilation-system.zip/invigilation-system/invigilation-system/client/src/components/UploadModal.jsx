import { useState } from 'react';
import Modal from './Modal.jsx';
import api from '../services/api.js';
import { parseFile, pick, dlTemplate, EX_KEYS, IN_KEYS } from '../utils/helpers.js';

/* Generic Excel/CSV upload dialog.
   kind: 'exam' -> imports exam schedule, 'invigilator' -> imports invigilators */
export default function UploadModal({ kind, onClose, onDone }) {
  const isExam = kind === 'exam';
  const [rows, setRows] = useState(null);
  const [fileName, setFileName] = useState('');
  const [errs, setErrs] = useState([]);
  const [busy, setBusy] = useState(false);

  const onFile = async (e) => {
    const file = e.target.files[0];
    if (!file) return;
    setFileName(file.name);
    try {
      const raw = await parseFile(file);
      const mapped = raw.map((r) => isExam ? {
        courseCode: pick(r, EX_KEYS.course),
        courseTitle: pick(r, EX_KEYS.title),
        section: pick(r, EX_KEYS.section),
        batch: pick(r, EX_KEYS.batch),
        examType: pick(r, EX_KEYS.type) || 'Final',
        date: pick(r, EX_KEYS.date),
        startTime: pick(r, EX_KEYS.start),
        endTime: pick(r, EX_KEYS.end),
        venue: pick(r, EX_KEYS.venue),
        studentsCount: pick(r, EX_KEYS.students),
        requiredInvigilators: pick(r, EX_KEYS.required),
      } : {
        name: pick(r, IN_KEYS.name),
        staffId: pick(r, IN_KEYS.staffId),
        department: pick(r, IN_KEYS.department),
        email: pick(r, IN_KEYS.email),
        phone: pick(r, IN_KEYS.phone),
        maxLoad: pick(r, IN_KEYS.maxLoad),
      }).filter((r) => (isExam ? r.courseCode : r.name));
      setRows(mapped);
      if (!mapped.length) setErrs(['No rows found. Make sure the FIRST ROW of the sheet contains column headers.']);
      else setErrs([]);
    } catch (err) { setErrs([err.message]); setRows(null); }
  };

  const doImport = async () => {
    setBusy(true);
    try {
      const res = await api(isExam ? '/api/exams/import' : '/api/invigilators/import',
        { method: 'POST', body: JSON.stringify(rows) });
      onDone(res);
    } catch (err) { setErrs([err.message]); setBusy(false); }
  };

  return (
    <Modal title={isExam ? 'Upload Exam Schedule (Excel / CSV)' : 'Upload Invigilators (Excel / CSV)'} onClose={onClose}>
      <div className="row" style={{ marginBottom: 12 }}>
        <input type="file" accept=".xlsx,.xls,.csv" onChange={onFile} />
        <button className="btn sm" onClick={() => dlTemplate(kind)}>
          Download template
        </button>
      </div>
      <p className="hint" style={{ marginBottom: 10 }}>
        {isExam
          ? 'Recognized columns: Course Code | Course Title | Section | Batch (e.g. 4th Year 1st Semester) | Exam Type (Mid/Final) | Date | Start Time | End Time | Venue | Students | Required Invigilators'
          : 'Recognized columns: Full Name | Staff ID | Department | Email | Phone | Max Load'}
        {' '}- column names can differ slightly, the app matches them automatically; extra columns are ignored.
      </p>
      {rows && rows.length > 0 && (
        <div style={{ maxHeight: 240, overflow: 'auto', border: '1px solid var(--line)', borderRadius: 8 }}>
          <table>
            <thead><tr>
              {isExam
                ? <><th>Course</th><th>Type</th><th>Batch</th><th>Date</th><th>Time</th><th>Venue</th><th>Needed</th></>
                : <><th>Name</th><th>Staff ID</th><th>Dept</th><th>Max Load</th></>}
            </tr></thead>
            <tbody>
              {rows.slice(0, 8).map((r, i) => isExam ? (
                <tr key={i}><td><b>{r.courseCode}</b> {r.courseTitle}</td><td>{r.examType}</td>
                  <td>{r.batch || '-'}</td>
                  <td>{String(r.date).slice(0, 10)}</td><td>{String(r.startTime).slice(0, 5)}-{String(r.endTime).slice(0, 5)}</td>
                  <td>{r.venue}</td><td>{r.requiredInvigilators || 1}</td></tr>
              ) : (
                <tr key={i}><td><b>{r.name}</b></td><td>{r.staffId}</td><td>{r.department}</td><td>{r.maxLoad || 4}</td></tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
      {rows && rows.length > 8 && <p className="hint">...and {rows.length - 8} more rows</p>}
      {errs.length > 0 && (
        <div style={{ background: '#fdecea', color: 'var(--red)', padding: 10, borderRadius: 8, marginTop: 10, fontSize: 12.5 }}>
          {errs.slice(0, 6).map((e, i) => <div key={i}>{e}</div>)}
        </div>
      )}
      <div className="mfoot">
        <button className="btn" onClick={onClose}>Cancel</button>
        <button className="btn primary" disabled={!rows || !rows.length || busy} onClick={doImport}>
          {busy ? 'Importing...' : `Import ${rows ? rows.length : 0} ${isExam ? 'exams' : 'invigilators'}`}
        </button>
      </div>
      {fileName && <p className="hint">File: {fileName}</p>}
    </Modal>
  );
}
