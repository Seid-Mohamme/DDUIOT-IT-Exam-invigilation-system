import { useState, useEffect, useRef } from 'react';
import api from '../services/api.js';

/* Notification bell for the navbar (right corner).
   Polls /api/notifications and shows the unread count.
   For invigilators it also shows TODAY's exam reminders. */
export default function NotificationBell({ user }) {
  const [items, setItems] = useState([]);
  const [unread, setUnread] = useState(0);
  const [open, setOpen] = useState(false);
  const [todayItems, setTodayItems] = useState([]);
  const boxRef = useRef(null);

  const load = async () => {
    try {
      const r = await api('/api/notifications');
      setItems(r.items || []);
      setUnread(r.unread || 0);
      if (user.role === 'invigilator') {
        const mine = await api('/api/assignments/mine');
        const today = new Date().toLocaleDateString('sv'); // YYYY-MM-DD local
        setTodayItems((mine || []).filter((a) => a.exam && a.exam.date === today));
      } else setTodayItems([]);
    } catch { /* silent */ }
  };

  useEffect(() => {
    load();
    const t = setInterval(load, 30000);      // refresh every 30s
    return () => clearInterval(t);
  }, []);

  /* close when clicking outside */
  useEffect(() => {
    const close = (e) => { if (open && boxRef.current && !boxRef.current.contains(e.target)) setOpen(false); };
    document.addEventListener('mousedown', close);
    return () => document.removeEventListener('mousedown', close);
  }, [open]);

  const markAll = async () => {
    const ids = items.filter((n) => n.id && !String(n.id).startsWith('todo-')).map((n) => n.id);
    try {
      if (ids.length) await api('/api/notifications/read', { method: 'POST', body: JSON.stringify({ ids }) });
      setUnread(0); setItems([]);
      load();
    } catch { /* silent */ }
  };

  const icon = (t) => ({
    absence: '⛔', excuse: '📝', measure: '⚖️', checkin: '✅', safe: '🛡️',
    feedback: '💬', todo: '⏰', info: 'ℹ️',
  }[t] || '🔔');

  const timeAgo = (d) => {
    const s = Math.max(0, (Date.now() - new Date(d).getTime()) / 1000);
    if (s < 60) return 'just now';
    if (s < 3600) return Math.floor(s / 60) + ' min ago';
    if (s < 86400) return Math.floor(s / 3600) + ' h ago';
    return Math.floor(s / 86400) + ' d ago';
  };

  return (
    <div className="bell-wrap" ref={boxRef}>
      <button className="bell-btn" title="Notifications" onClick={() => { setOpen(!open); if (!open) load(); }}>
        🔔
        {unread > 0 && <span className="bell-badge">{unread > 9 ? '9+' : unread}</span>}
      </button>
      {open && (
        <div className="bell-panel">
          <div className="bell-head">
            <b>Notifications</b>
            {items.length > 0 && <button className="btn sm" onClick={markAll}>Mark all read</button>}
          </div>
          {todayItems.length > 0 && (
            <div className="bell-today">
              <b>⏰ Today's exams ({todayItems.length})</b>
              {todayItems.map((a) => (
                <div className="bell-item" key={'t' + a._id}>
                  <div className="bell-title">{icon('checkin')} You invigilate <b>{a.exam.courseCode}</b> today</div>
                  <div className="bell-body">{a.exam.startTime} - {a.exam.endTime}{a.exam.venue ? ' · ' + a.exam.venue : ''}</div>
                </div>
              ))}
            </div>
          )}
          <div className="bell-list">
            {items.length === 0 && todayItems.length === 0 && (
              <div className="bell-empty">No notifications yet.<br />Reminders for today's exams and absence alerts appear here.</div>
            )}
            {items.map((n) => (
              <div className={'bell-item' + (n.urgent ? ' urgent' : '')} key={n.id}>
                <div className="bell-title">{icon(n.type)} {n.title}</div>
                {n.body && <div className="bell-body">{n.body}</div>}
                <div className="bell-time">{timeAgo(n.at)}</div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
