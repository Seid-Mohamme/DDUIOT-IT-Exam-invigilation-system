import { useMemo, useState, useEffect } from 'react';
import api from '../services/api.js';
import Modal from '../components/Modal.jsx';
import { fmtDate, fmtTime } from '../utils/helpers.js';

/* Invigilator view: my assigned exams - course, batch, room, date and time.
   Plus: TODAY reminders, "I am in the exam room" + "exam running safely"
   confirmations, absence explanations and feedback to the department. */
export default function MyExams({ user, assigns, reload, notify }) {
  const [missed, setMissed] = useState([]);          // my absence records
  const [fbFor, setFbFor] = useState(null);          // assignment for the feedback modal
  const [fbText, setFbText] = useState('');
  const [fbCat, setFbCat] = useState('General');
  const [excuseFor, setExcuseFor] = useState(null);  // absence record to explain
  const [excuseText, setExcuseText] = useState('');
  const [sending, setSending] = useState(false);

  const loadMissed = () => api('/api/missed/mine').then(setMissed).catch(() => {});
  useEffect(() => { loadMissed(); }, []);

  const today = new Date().toLocaleDateString('sv'); // YYYY-MM-DD in local time
  const sorted = useMemo(() => {
    return [...assigns].sort((a, b) =>
      a.exam.date === b.exam.date
        ? (toMin(a.exam.startTime) - toMin(b.exam.startTime))
        : (a.exam.date < b.exam.date ? -1 : 1));
  }, [assigns]);

  const byDate = useMemo(() => {
    const m = new Map();
    sorted.forEach((a) => {
      if (!m.has(a.exam.date)) m.set(a.exam.date, []);
      m.get(a.exam.date).push(a);
    });
    return [...m.entries()];
  }, [sorted]);

  const todayList = sorted.filter((a) => a.exam.date === today);
  const instructorCount = assigns.filter((a) => a.role === 'Instructor').length;
  const unexplained = missed.filter((m) => !m.excuseText);

  /* ---------- invigilator actions ---------- */
  const checkIn = async (a) => {
    try {
      await api('/api/assignments/' + a._id + '/checkin', { method: 'PATCH' });
      notify('Check-in sent to the department: "I am in the exam room"');
      reload();
    } catch (e) { notify(e.message, 'err'); }
  };
  const confirmSafe = async (a) => {
    try {
      await api('/api/assignments/' + a._id + '/confirm-safe', { method: 'PATCH' });
      notify('Confirmed: "The exam is continuing safely" - the department is notified');
      reload();
    } catch (e) { notify(e.message, 'err'); }
  };
  const sendFeedback = async () => {
    if (!fbText.trim()) { notify('Please write your feedback', 'err'); return; }
    setSending(true);
    try {
      await api('/api/feedback', { method: 'POST', body: JSON.stringify({
        assignmentId: fbFor._id, category: fbCat, message: fbText.trim() }) });
      notify('Feedback sent to the department - thank you');
      setFbFor(null); setFbText('');
    } catch (e) { notify(e.message, 'err'); }
    finally { setSending(false); }
  };
  const sendExcuse = async () => {
    if (!excuseText.trim()) { notify('Please write the reason why you missed it', 'err'); return; }
    setSending(true);
    try {
      await api('/api/missed/' + excuseFor._id + '/excuse',
        { method: 'POST', body: JSON.stringify({ text: excuseText.trim() }) });
      notify('Reason submitted - the Department Head will take the measure');
      setExcuseFor(null); setExcuseText('');
      loadMissed();
    } catch (e) { notify(e.message, 'err'); }
    finally { setSending(false); }
  };

  const clock = (d) => new Date(d).toLocaleTimeString('en-GB', { hour: '2-digit', minute: '2-digit' });

  return (
    <div>
      <div className="page-title">My Invigilation Schedule</div>
      <div className="page-sub">
        {user.invigilatorName ? 'Invigilator: ' + user.invigilatorName + ' - ' : ''}
        {assigns.length} exam session(s) assigned to you
      </div>

      {/* ---- TODAY reminders ---- */}
      {todayList.length > 0 && (
        <div className="today-banner no-print">
          <b>⏰ TODAY - {todayList.length} exam session(s) for you:</b>
          {todayList.map((a) => (
            <div key={a._id} style={{ marginTop: 6 }}>
              📌 <b>{a.exam.courseCode}</b> ({a.exam.courseTitle}) · {fmtTime(a.exam.startTime)} - {fmtTime(a.exam.endTime)}
              {' '}· {a.exam.venue || 'TBA'}{a.exam.batch ? ' · ' + a.exam.batch : ''}
              {a.checkInAt ? <span className="badge accepted" style={{ marginLeft: 8 }}>In room since {clock(a.checkInAt)}</span>
                : <button className="btn sm primary" style={{ marginLeft: 8 }} onClick={() => checkIn(a)}>I am in the exam room</button>}
            </div>
          ))}
        </div>
      )}

      {/* ---- absence records: submit your reason ---- */}
      {missed.length > 0 && (
        <div className="card" style={{ borderLeft: '4px solid var(--red)' }}>
          <h3>Missed invigilation records</h3>
          {missed.map((m) => (
            <div className="sug-item sug-busy" key={m._id}>
              <div>
                <b>{m.exam.courseCode}</b> - {fmtDate(m.exam.date)}, {fmtTime(m.exam.startTime)}
                {m.note ? <div className="sug-meta">Coordinator note: {m.note}</div> : null}
                {m.excuseText
                  ? <div className="sug-meta">Your reason: "{m.excuseText}" {m.actionTaken ? <>· <b>Measure taken:</b> {m.actionTaken}</> : ' · waiting for the measure of the Department Head'}</div>
                  : <div className="sug-clash">Please announce to the Department Head WHY you missed this invigilation.</div>}
              </div>
              {!m.excuseText && (
                <button className="btn sm primary" onClick={() => { setExcuseFor(m); setExcuseText(''); }}>
                  Submit my reason
                </button>
              )}
            </div>
          ))}
        </div>
      )}

      {assigns.length === 0 ? (
        <div className="card">
          <div className="empty">
            No exams assigned to you yet.<br />
            The admin publishes assignments after scheduling - check again later.
          </div>
        </div>
      ) : (
        <>
          <div className="grid4 no-print">
            <div className="stat"><div className="n">{assigns.length}</div><div className="l">Total exams assigned</div></div>
            <div className="stat"><div className="n">{instructorCount}</div><div className="l">As Instructor-in-charge</div></div>
            <div className="stat"><div className="n">{byDate.length}</div><div className="l">Exam days</div></div>
            <div className="stat">
              <div className="n">{new Set(sorted.map((a) => a.exam.venue).filter(Boolean)).size}</div>
              <div className="l">Different rooms</div>
            </div>
          </div>

          <div className="card no-print">
            <div className="row">
              <button className="btn gold" onClick={() => window.print()}>Print my schedule</button>
              <button className="btn" onClick={() => { reload(); loadMissed(); }}>Refresh</button>
              <span className="hint">Use the buttons on each exam: check in when you arrive, confirm the exam is running safely, or send feedback.</span>
            </div>
          </div>

          {byDate.map(([date, list]) => (
            <div key={date}>
              <div className="date-head">
                {fmtDate(date)}{date === today ? '  ·  TODAY' : ''}
              </div>
              {list.map((a) => (
                <div className="exam-block my-exam" key={a._id} style={date === today ? { borderLeft: '4px solid var(--gold)' } : null}>
                  <div className="exam-line">
                    <span className="code">{a.exam.courseCode}</span>
                    <span>{a.exam.courseTitle}</span>
                    <span className={'badge ' + a.exam.examType.toLowerCase()}>{a.exam.examType}</span>
                    {a.role === 'Instructor' && <span className="badge instructor">Instructor-in-charge</span>}
                    <span className="badge status">{a.status}</span>
                    {a.checkInAt && <span className="badge accepted">✅ In room since {clock(a.checkInAt)}</span>}
                    {a.runningConfirmedAt && <span className="badge accepted">🛡️ Running safely ({clock(a.runningConfirmedAt)})</span>}
                  </div>
                  <div className="my-exam-details">
                    <div><i>Time</i><b>{fmtTime(a.exam.startTime)} - {fmtTime(a.exam.endTime)}</b></div>
                    <div><i>Room / Venue</i><b>{a.exam.venue || 'TBA'}</b></div>
                    <div><i>Batch</i><b>{a.exam.batch || '-'}</b></div>
                    {a.exam.section && <div><i>Section</i><b>{a.exam.section}</b></div>}
                    <div><i>Students</i><b>{a.exam.studentsCount || '-'}</b></div>
                  </div>
                  <div className="row no-print" style={{ marginTop: 10 }}>
                    {!a.checkInAt && (
                      <button className="btn sm primary" onClick={() => checkIn(a)}>✅ I am in the exam room</button>
                    )}
                    {a.checkInAt && !a.runningConfirmedAt && (
                      <button className="btn sm gold" onClick={() => confirmSafe(a)}>🛡️ Exam is running safely</button>
                    )}
                    <button className="btn sm" onClick={() => { setFbFor(a); setFbCat('General'); setFbText(''); }}>💬 Give feedback</button>
                  </div>
                </div>
              ))}
            </div>
          ))}
        </>
      )}

      {fbFor && (
        <Modal title={'Feedback - ' + fbFor.exam.courseCode} onClose={() => setFbFor(null)}>
          <p className="hint" style={{ marginBottom: 10 }}>
            {fbFor.exam.courseTitle} | {fmtDate(fbFor.exam.date)} | {fmtTime(fbFor.exam.startTime)} - {fmtTime(fbFor.exam.endTime)} | {fbFor.exam.venue || 'TBA'}
          </p>
          <div className="full">
            <label>Category</label>
            <select value={fbCat} onChange={(e) => setFbCat(e.target.value)}>
              <option>General</option>
              <option>Issue</option>
              <option>Suggestion</option>
              <option>Other</option>
            </select>
          </div>
          <div className="full" style={{ marginTop: 10 }}>
            <label>Your message to the department *</label>
            <textarea rows="4" style={{ width: '100%', padding: 9, border: '1px solid var(--line)', borderRadius: 8, fontFamily: 'inherit' }}
              value={fbText} onChange={(e) => setFbText(e.target.value)}
              placeholder="e.g. Everything went well. / The room was locked when I arrived. / Suggest adding one more invigilator for large batches..." />
          </div>
          <div className="mfoot">
            <button className="btn" onClick={() => setFbFor(null)}>Cancel</button>
            <button className="btn primary" disabled={sending} onClick={sendFeedback}>{sending ? 'Sending...' : 'Send feedback'}</button>
          </div>
        </Modal>
      )}

      {excuseFor && (
        <Modal title={'Why did you miss ' + excuseFor.exam.courseCode + '?'} onClose={() => setExcuseFor(null)}>
          <p className="hint" style={{ marginBottom: 10 }}>
            This explanation goes to the Exam Coordinator and the Department Head, who will take the measure.
          </p>
          <div className="full">
            <label>Your reason *</label>
            <textarea rows="4" style={{ width: '100%', padding: 9, border: '1px solid var(--line)', borderRadius: 8, fontFamily: 'inherit' }}
              value={excuseText} onChange={(e) => setExcuseText(e.target.value)}
              placeholder="e.g. Sudden illness with medical certificate attached / Official duty assigned the same morning / Family emergency..." />
          </div>
          <div className="mfoot">
            <button className="btn" onClick={() => setExcuseFor(null)}>Cancel</button>
            <button className="btn primary" disabled={sending} onClick={sendExcuse}>{sending ? 'Sending...' : 'Submit reason'}</button>
          </div>
        </Modal>
      )}
    </div>
  );
}

const toMin = (t) => { const [h, m] = String(t).split(':').map(Number); return h * 60 + m; };
