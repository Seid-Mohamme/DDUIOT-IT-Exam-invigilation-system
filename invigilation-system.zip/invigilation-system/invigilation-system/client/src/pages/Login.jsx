import { useState } from 'react';
import api from '../services/api.js';

/* Login screen - Department Head (admin) or Departmental Invigilator */
export default function Login({ onLogin, notify }) {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState('');

  const submit = async (e) => {
    e.preventDefault();
    if (!email.trim() || !password) { setErr('Enter your email and password'); return; }
    setBusy(true); setErr('');
    try {
      const res = await api('/api/auth/login', {
        method: 'POST',
        body: JSON.stringify({ email: email.trim(), password }),
      });
      onLogin(res);
    } catch (e2) {
      setErr(e2.message);
    } finally { setBusy(false); }
  };

  return (
    <div className="login-page">
      <form className="login-card" onSubmit={submit}>
        <div className="login-brand">
          <img src="/logo.jpg" alt="Dire Dawa University logo" className="login-logo" />
          <h1>Dire Dawa University - Institute of Technology</h1>
          <h2>Information Technology Invigilation System</h2>
        </div>

        <label>Email</label>
        <input type="email" value={email} autoFocus
          onChange={(e) => setEmail(e.target.value)} placeholder="admin@ddu.edu.et" />
        <label>Password</label>
        <input type="password" value={password}
          onChange={(e) => setPassword(e.target.value)} placeholder="••••••••" />

        {err && <div className="login-err">{err}</div>}

        <button className="btn primary login-btn" disabled={busy}>
          {busy ? 'Logging in...' : 'Login'}
        </button>

        <div className="login-hint">
          <b>Admin (Department Head):</b> admin@ddu.edu.et / admin@123<br />
          <b>Exam Coordinator (demo):</b> coordinator@ddu.edu.et / coord@123<br />
          <b>Invigilator (demo):</b> instructor@ddu.edu.et / invig@123
        </div>
      </form>
    </div>
  );
}
