import { useState, useMemo, useEffect } from 'react';
import api from '../services/api.js';
import Modal from '../components/Modal.jsx';
import UploadModal from '../components/UploadModal.jsx';
import { dlTemplate } from '../utils/helpers.js';

export default function Invigilators({ invs, assigns, run, notify, busy }) {
  const [modal, setModal] = useState(false);
  const [upload, setUpload] = useState(false);
  const [f, setF] = useState({ name: '', staffId: '', department: '', email: '', phone: '', maxLoad: 4 });

  /* --- login accounts for departmental invigilators --- */
  const [users, setUsers] = useState([]);
  const [lf, setLf] = useState({ invigilatorId: '', email: '', password: '' });
  const [creating, setCreating] = useState(false);

  const loadUsers = () => api('/api/auth/users').then(setUsers).catch(() => {});
  useEffect(() => { loadUsers(); }, []);

  const createLogin = async () => {
    if (!lf.invigilatorId) { notify('Select the invigilator first', 'err'); return; }
    if (!lf.email.trim() || lf.password.length < 4) { notify('Email and a password (4+ characters) are required', 'err'); return; }
    setCreating(true);
    try {
      await api('/api/auth/users', { method: 'POST', body: JSON.stringify({
        invigilatorId: lf.invigilatorId, email: lf.email.trim(), password: lf.password, role: 'invigilator',
      }) });
      notify('Login created - the invigilator can now sign in');
      setLf({ invigilatorId: '', email: '', password: '' });
      loadUsers();
    } catch (e) { notify(e.message, 'err'); }
    finally { setCreating(false); }
  };

  const resetPw = async (u) => {
    const pw = window.prompt('New password for ' + u.email + ':');
    if (!pw) return;
    try { await api('/api/auth/users/' + u.id + '/password', { method: 'PUT', body: JSON.stringify({ password: pw }) }); notify('Password reset'); }
    catch (e) { notify(e.message, 'err'); }
  };

  const delUser = async (u) => {
    if (!window.confirm('Delete the login ' + u.email + '?')) return;
    try { await api('/api/auth/users/' + u.id, { method: 'DELETE' }); notify('Login deleted'); loadUsers(); }
    catch (e) { notify(e.message, 'err'); }
  };

  const load = useMemo(() => {
    const m = {};
    assigns.forEach((a) => { if (a.invigilator) m[a.invigilator._id] = (m[a.invigilator._id] || 0) + 1; });
    return m;
  }, [assigns]);
  const set = (k) => (e) => setF({ ...f, [k]: e.target.value });
  const setL = (k) => (e) => setLf({ ...lf, [k]: e.target.value });
  const hasLogin = (v) => users.some((u) => u.invigilatorId === v._id);

  return (
    <div>
      <div className="page-title">Invigilators</div>
      <div className="page-sub">Staff available for invigilation - add manually or upload the list from Excel/CSV</div>
      <div className="card no-print">
        <div className="row">
          <button className="btn primary" onClick={() => setModal(true)}>+ Add invigilator</button>
          <button className="btn gold" onClick={() => setUpload(true)}>Upload Excel / CSV</button>
          <button className="btn" onClick={() => dlTemplate('invigilator')}>Download template</button>
          <button className="btn danger" disabled={busy || invs.length === 0}
            onClick={() => { if (window.confirm('Delete ALL invigilators (and their assignments)?')) run(() => api('/api/invigilators', { method: 'DELETE' }), 'All invigilators deleted'); }}>
            Delete all
          </button>
        </div>
      </div>
      <div className="card" style={{ padding: 0 }}>
        {invs.length === 0 ? <div className="empty">No invigilators yet - add one or upload the staff list.</div> : (
          <table>
            <thead><tr>
              <th>Name</th><th>Staff ID</th><th>Department</th><th>Email</th><th>Phone</th>
              <th>Load</th><th>Login</th><th className="no-print">Actions</th>
            </tr></thead>
            <tbody>
              {invs.map((v) => (
                <tr key={v._id}>
                  <td><b>{v.name}</b></td>
                  <td>{v.staffId}</td>
                  <td>{v.department}</td>
                  <td>{v.email}</td>
                  <td>{v.phone}</td>
                  <td>
                    <b style={{ color: (load[v._id] || 0) >= v.maxLoad ? 'var(--red)' : 'var(--green)' }}>{load[v._id] || 0}</b>
                    {' / '}{v.maxLoad}
                  </td>
                  <td>{hasLogin(v)
                    ? <span className="badge accepted">Created</span>
                    : <span className="badge assigned">No login</span>}</td>
                  <td className="actions no-print">
                    <button className="btn sm danger" onClick={() => {
                      if (window.confirm('Remove ' + v.name + ' and all of their assignments?'))
                        run(() => api('/api/invigilators/' + v._id, { method: 'DELETE' }), 'Invigilator removed');
                    }}>Delete</button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>

      <div className="card">
        <h3>Invigilator logins</h3>
        <p className="hint" style={{ marginBottom: 10 }}>
          Every invigilator you add or upload gets a login account AUTOMATICALLY
          (default password <b>invig@123</b> - reset it here or in User Accounts).
          With a login each invigilator can sign in and see only their own exams, rooms and batches.
        </p>
        <div className="row" style={{ alignItems: 'flex-end' }}>
          <div style={{ width: 220 }}>
            <label>Invigilator</label>
            <select value={lf.invigilatorId} onChange={setL('invigilatorId')}>
              <option value="">- select -</option>
              {invs.filter((v) => !hasLogin(v)).map((v) => (
                <option key={v._id} value={v._id}>{v.name} ({v.staffId})</option>
              ))}
            </select>
          </div>
          <div style={{ width: 220 }}>
            <label>Email</label>
            <input type="email" value={lf.email} onChange={setL('email')} placeholder="name@ddu.edu.et" />
          </div>
          <div style={{ width: 160 }}>
            <label>Password</label>
            <input type="text" value={lf.password} onChange={setL('password')} placeholder="min 4 characters" />
          </div>
          <button className="btn primary" disabled={creating || invs.length === 0} onClick={createLogin}>
            {creating ? 'Creating...' : '+ Create login'}
          </button>
        </div>

        {users.filter((u) => u.role === 'invigilator').length > 0 && (
          <table style={{ marginTop: 14 }}>
            <thead><tr><th>Name</th><th>Email</th><th>Linked invigilator</th><th className="no-print">Actions</th></tr></thead>
            <tbody>
              {users.filter((u) => u.role === 'invigilator').map((u) => (
                <tr key={u.id}>
                  <td><b>{u.name}</b></td>
                  <td>{u.email}</td>
                  <td>{u.invigilatorName || '-'}</td>
                  <td className="actions no-print">
                    <button className="btn sm" onClick={() => resetPw(u)}>Reset password</button>
                    <button className="btn sm danger" onClick={() => delUser(u)}>Delete</button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>

      {modal && (
        <Modal title="Add invigilator" onClose={() => setModal(false)}>
          <div className="fgrid">
            <div className="full"><label>Full name *</label><input type="text" value={f.name} onChange={set('name')} placeholder="Alemu Bekele" /></div>
            <div><label>Staff ID</label><input type="text" value={f.staffId} onChange={set('staffId')} placeholder="DDU/STF/2101" /></div>
            <div><label>Department</label><input type="text" value={f.department} onChange={set('department')} placeholder="CSE" /></div>
            <div><label>Email</label><input type="email" value={f.email} onChange={set('email')} /></div>
            <div><label>Phone</label><input type="text" value={f.phone} onChange={set('phone')} /></div>
            <div><label>Max exam sessions</label><input type="number" min="1" value={f.maxLoad} onChange={set('maxLoad')} /></div>
          </div>
          <div className="mfoot">
            <button className="btn" onClick={() => setModal(false)}>Cancel</button>
            <button className="btn primary" onClick={() => {
              if (!f.name.trim()) { alert('Name is required'); return; }
              run(() => api('/api/invigilators', { method: 'POST', body: JSON.stringify(f) }),
                (r) => 'Invigilator added - login account created automatically (' + (r.loginEmail || 'see User Accounts')
                  + ', default password ' + (r.defaultPassword || 'invig@123') + ')')
                .then(() => { setModal(false); setF({ name: '', staffId: '', department: '', email: '', phone: '', maxLoad: 4 }); loadUsers(); });
            }}>Save</button>
          </div>
        </Modal>
      )}
      {upload && <UploadModal kind="invigilator" onClose={() => setUpload(false)}
        onDone={(res) => { setUpload(false); notify('Imported ' + res.imported + ' invigilator(s) - ' + (res.loginsCreated || 0)
          + ' login(s) auto-created (default password ' + (res.defaultPassword || 'invig@123') + ')'
          + (res.errors.length ? ' - skipped: ' + res.errors.slice(0, 3).join(' | ') : ''), res.errors.length ? 'warn' : 'ok'); run(() => Promise.resolve()); loadUsers(); }} />}
    </div>
  );
}
