import { useState, useEffect } from 'react';
import api from '../services/api.js';
import Modal from '../components/Modal.jsx';
import { fmtDate, fmtTime } from '../utils/helpers.js';
import * as XLSX from 'xlsx';

/* Absences & Feedback (staff: Department Head + Exam Coordinator)
   1. Missed invigilation records - excuse from the invigilator,
      Department Head takes the measure, ONE-FILE report download
   2. Feedback sent by invigilators                                */
export default function Incidents({ user, run, notify, busy }) {
  const [records, setRecords] = useState([]);
  const [feedback, setFeedback] = useState([]);
  const [action, setAction] = useState(null);   // record being measured
  const [actionText, setActionText] = useState('');

  const load = () => Promise.all([api('/api/missed'), api('/api/feedback')])
    .then(([m, f]) => { setRecords(m); setFeedback(f); })
    .catch((e) => notify(e.message, 'err'));
  useEffect(() => { load(); }, []);

  const saveAction = async () => {
    if (!actionText.trim()) { notify('Describe the measure taken', 'err'); return; }
    try {
      await api('/api/missed/' + action._id + '/action',
        { method: 'PUT', body: JSON.stringify({ actionTaken: actionText.trim() }) });
      notify('Measure recorded - the invigilator has been notified');
      setAction(null); setActionText('');
      load();
    } catch (e) { notify(e.message, 'err'); }
  };

  const delRecord = async (r) => {
    if (!window.confirm('Delete the absence record of ' + r.invigilator.name + ' for ' + r.exam.courseCode + '?')) return;
    try { await api('/api/missed/' + r._id, { method: 'DELETE' }); notify('Record deleted'); load(); }
    catch (e) { notify(e.message, 'err'); }
  };

  /* ONE Excel file: missed invigilation report for the Department Head */
  const downloadReport = () => {
    const head = ['Recorded On', 'Exam Date', 'Course Code', 'Course Title', 'Batch', 'Time', 'Venue',
      'Invigilator', 'Staff ID', 'Department', 'Reported By', 'Coordinator Note',
      'Reason Submitted By Invigilator', 'Reason Submitted At', 'Measure Taken (Department Head)', 'Status'];
    const rows = records.map((r) => [
      new Date(r.createdAt).toLocaleString('en-GB'),
      r.exam?.date || '', r.exam?.courseCode || '', r.exam?.courseTitle || '', r.exam?.batch || '',
      r.exam ? fmtTime(r.exam.startTime) + ' - ' + fmtTime(r.exam.endTime) : '',
      r.exam?.venue || '', r.invigilator?.name || '', r.invigilator?.staffId || '',
      r.invigilator?.department || '', r.reportedBy?.name || '', r.note || '',
      r.excuseText || '(not submitted yet)',
      r.excuseAt ? new Date(r.excuseAt).toLocaleString('en-GB') : '',
      r.actionTaken || '(pending)', r.status,
    ]);
    const byInv = {};
    records.forEach((r) => {
      const k = (r.invigilator?.name || '?') + ' (' + (r.invigilator?.staffId || '-') + ')';
      byInv[k] = (byInv[k] || 0) + 1;
    });
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, XLSX.utils.aoa_to_sheet([head, ...rows]), 'Missed Invigilations');
    XLSX.utils.book_append_sheet(wb, XLSX.utils.aoa_to_sheet(
      [['Invigilator', 'Missed exams'], ...Object.entries(byInv).map(([k, v]) => [k, v])]), 'By Invigilator');
    XLSX.writeFile(wb, 'missed-invigilation-report-' + new Date().toISOString().slice(0, 10) + '.xlsx');
    notify('Absence report downloaded (one Excel file)');
  };

  const openCount = records.filter((r) => r.status !== 'Closed').length;

  return (
    <div>
      <div className="page-title">Absences &amp; Feedback</div>
      <div className="page-sub">
        Missed invigilation records with the invigilator's reason - the Department Head takes the measure.
        Absences also create an immediate "replace" notification.
      </div>

      <div className="card no-print">
        <div className="row">
          <button className="btn primary" disabled={records.length === 0} onClick={downloadReport}>
            ⬇ Download absence report (one Excel file)
          </button>
          <span className="hint">{records.length} record(s){openCount ? `, ${openCount} still open` : ''}</span>
        </div>
        <p className="hint" style={{ marginTop: 8 }}>
          To record a new absence open the <b>Assignments</b> tab and press <b>"Missed"</b> on that
          invigilator's chip. The department is notified immediately to replace the invigilator,
          the invigilator can then submit their reason here, and the report above is used to take the measure.
        </p>
      </div>

      <div className="card" style={{ padding: 0 }}>
        {records.length === 0 ? <div className="empty">No missed invigilation recorded - well done!</div> : (
          <table>
            <thead><tr>
              <th>Exam</th><th>Date &amp; time</th><th>Invigilator</th><th>Reported by</th>
              <th>Reason (invigilator)</th><th>Measure taken</th><th>Status</th>
              <th className="no-print">Actions</th>
            </tr></thead>
            <tbody>
              {records.map((r) => (
                <tr key={r._id}>
                  <td><b>{r.exam.courseCode}</b><br /><span className="hint">{r.exam.courseTitle}</span></td>
                  <td>{fmtDate(r.exam.date)}<br /><span className="hint">{fmtTime(r.exam.startTime)} - {fmtTime(r.exam.endTime)}{r.exam.venue ? ' · ' + r.exam.venue : ''}</span></td>
                  <td><b>{r.invigilator.name}</b><br /><span className="hint">{r.invigilator.staffId}</span></td>
                  <td>{r.reportedBy?.name || '-'}{r.note ? <><br /><span className="hint">Note: {r.note}</span></> : null}</td>
                  <td style={{ maxWidth: 220 }}>
                    {r.excuseText
                      ? <>"{r.excuseText}"<br /><span className="hint">{r.excuseAt ? new Date(r.excuseAt).toLocaleString('en-GB') : ''}</span></>
                      : <span className="badge assigned">waiting for reason</span>}
                  </td>
                  <td style={{ maxWidth: 200 }}>
                    {r.actionTaken
                      ? <>{r.actionTaken}<br /><span className="hint">by {r.actionBy?.name || 'Department Head'}</span></>
                      : <span className="badge assigned">pending measure</span>}
                  </td>
                  <td><span className={'badge ' + (r.status === 'Closed' ? 'accepted' : r.status === 'Explained' ? 'status' : 'declined')}>{r.status}</span></td>
                  <td className="actions no-print">
                    {user.role === 'admin' && r.status !== 'Closed' && (
                      <button className="btn sm primary" onClick={() => { setAction(r); setActionText(''); }}>Take measure</button>
                    )}
                    {user.role === 'admin' && <button className="btn sm danger" onClick={() => delRecord(r)}>Delete</button>}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>

      <div className="card">
        <h3>Feedback from invigilators</h3>
        {feedback.length === 0 ? (
          <p className="hint">No feedback yet - invigilators send it from their "My Exams" page.</p>
        ) : (
          <table>
            <thead><tr><th>When</th><th>Invigilator</th><th>Exam</th><th>Category</th><th>Message</th></tr></thead>
            <tbody>
              {feedback.map((f) => (
                <tr key={f._id}>
                  <td>{new Date(f.createdAt).toLocaleString('en-GB')}</td>
                  <td><b>{f.invigilator.name}</b><br /><span className="hint">{f.invigilator.staffId}</span></td>
                  <td>{f.exam ? f.exam.courseCode : '-'}</td>
                  <td><span className="badge status">{f.category}</span></td>
                  <td style={{ maxWidth: 360 }}>{f.message}</td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>

      {action && (
        <Modal title={'Take measure - ' + action.invigilator.name} onClose={() => setAction(null)}>
          <p className="hint" style={{ marginBottom: 10 }}>
            {action.exam.courseCode} missed on {fmtDate(action.exam.date)} ({fmtTime(action.exam.startTime)} - {fmtTime(action.exam.endTime)})
            {action.excuseText ? <> · reason submitted: "{action.excuseText}"</> : ' · no reason submitted yet'}
          </p>
          <div className="full">
            <label>Measure taken by the Department Head *</label>
            <textarea rows="4" style={{ width: '100%', padding: 9, border: '1px solid var(--line)', borderRadius: 8, fontFamily: 'inherit' }}
              value={actionText} onChange={(e) => setActionText(e.target.value)}
              placeholder="e.g. Official warning letter issued; replacement arranged with Dawit Alemu; one session deduction from allowance..." />
          </div>
          <div className="mfoot">
            <button className="btn" onClick={() => setAction(null)}>Cancel</button>
            <button className="btn primary" onClick={saveAction}>Record measure &amp; notify</button>
          </div>
        </Modal>
      )}
    </div>
  );
}
