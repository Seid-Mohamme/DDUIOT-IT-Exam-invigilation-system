import { useMemo, useState } from 'react';
import * as XLSX from 'xlsx';
import api from '../services/api.js';
import { fmtDate, fmtTime, BATCHES } from '../utils/helpers.js';

/* Reports & Share - Department Head only.
   - view / filter every assigned invigilator
   - download everything as ONE Excel file (Assignments + By Invigilator + Summary)
   - send the report file or a text summary to a Telegram group            */
export default function Reports({ exams, invs, assigns, stats, run, notify, busy }) {
  const [type, setType] = useState('');
  const [batch, setBatch] = useState('');
  const [q, setQ] = useState('');
  const [tg, setTg] = useState(null);            // telegram settings { configured, chatId, botTokenMasked }
  const [showTg, setShowTg] = useState(false);
  const [token, setTgToken] = useState('');
  const [chatId, setTgChatId] = useState('');
  const [tgBusy, setTgBusy] = useState(false);

  /* ---------- flatten assignments into report rows ---------- */
  const rows = useMemo(() => {
    return assigns
      .filter((a) => a.exam && a.invigilator)
      .filter((a) => !type || a.exam.examType === type)
      .filter((a) => !batch || a.exam.batch === batch)
      .filter((a) => {
        if (!q.trim()) return true;
        const s = q.toLowerCase();
        return [a.exam.courseCode, a.exam.courseTitle, a.invigilator.name,
          a.invigilator.staffId, a.exam.venue, a.exam.batch]
          .some((v) => String(v || '').toLowerCase().includes(s));
      })
      .map((a) => ({
        Date: fmtDate(a.exam.date),
        'Start Time': fmtTime(a.exam.startTime),
        'End Time': fmtTime(a.exam.endTime),
        'Course Code': a.exam.courseCode,
        'Course Title': a.exam.courseTitle || '',
        'Exam Type': a.exam.examType,
        Batch: a.exam.batch || '',
        Section: a.exam.section || '',
        'Room / Venue': a.exam.venue || '',
        Invigilator: a.invigilator.name,
        'Staff ID': a.invigilator.staffId || '',
        Department: a.invigilator.department || '',
        Role: a.role,
        Status: a.status,
      }))
      .sort((a, b) => String(a.Date).localeCompare(String(b.Date)) || String(a['Start Time']).localeCompare(String(b['Start Time'])));
  }, [assigns, type, batch, q]);

  const perInv = useMemo(() => {
    const m = {};
    assigns.filter((a) => a.invigilator && a.exam).forEach((a) => {
      const k = a.invigilator._id;
      m[k] = m[k] || { name: a.invigilator.name, staffId: a.invigilator.staffId || '',
        dept: a.invigilator.department || '', total: 0, instructor: 0, courses: [] };
      m[k].total += 1;
      if (a.role === 'Instructor') m[k].instructor += 1;
      m[k].courses.push(a.exam.courseCode);
    });
    return Object.values(m).sort((a, b) => b.total - a.total || a.name.localeCompare(b.name));
  }, [assigns]);

  /* ---------- build ONE Excel workbook ---------- */
  const buildWorkbook = () => {
    const wb = XLSX.utils.book_new();

    const ws1 = XLSX.utils.json_to_sheet(rows.length ? rows : [{ Info: 'No assignments for the current filter' }]);
    XLSX.utils.book_append_sheet(wb, ws1, 'All Assignments');

    const ws2 = XLSX.utils.json_to_sheet(perInv.length ? perInv.map((v) => ({
      Invigilator: v.name, 'Staff ID': v.staffId, Department: v.dept,
      'Total Exams': v.total, 'As Instructor': v.instructor,
      Courses: v.courses.join(', '),
    })) : [{ Info: 'No assignments yet' }]);
    XLSX.utils.book_append_sheet(wb, ws2, 'By Invigilator');

    const today = new Date().toISOString().slice(0, 10);
    const summary = [
      ['DDU - Institute of Technology, Information Technology Department'],
      ['Invigilation Assignment Report', ''],
      ['Generated on', today],
      [''],
      ['Total exams', stats ? stats.exams : exams.length],
      ['Mid exams', stats ? stats.byType.Mid : '-'],
      ['Final exams', stats ? stats.byType.Final : '-'],
      ['Total invigilators', stats ? stats.invigilators : invs.length],
      ['Total invigilation assignments', stats ? stats.assignments : assigns.length],
      ['Invigilator positions required', stats ? stats.required : '-'],
      ['Invigilator positions filled', stats ? stats.filled : '-'],
      ['Exams fully covered', stats ? stats.fullyAssigned : '-'],
      [''],
      ['Per batch', 'Exams', 'Assignments'],
      ...(stats ? stats.byBatch.map((b) => [b.batch, b.exams, b.assignments]) : []),
    ];
    const ws3 = XLSX.utils.aoa_to_sheet(summary);
    XLSX.utils.book_append_sheet(wb, ws3, 'Summary');

    return { wb, name: `DDU-IT_Invigilation_Report_${today}.xlsx` };
  };

  const downloadReport = () => {
    const { wb, name } = buildWorkbook();
    XLSX.writeFile(wb, name);
    notify('Report downloaded: ' + name);
  };

  /* ---------- Telegram sharing ---------- */
  const loadTgSettings = async () => {
    try { setTg(await api('/api/telegram/settings')); }
    catch (e) { notify(e.message, 'err'); }
  };

  const openTgSettings = () => {
    setShowTg(true);
    if (!tg) loadTgSettings();
  };

  const saveTg = async () => {
    setTgBusy(true);
    try {
      await api('/api/telegram/settings', {
        method: 'PUT', body: JSON.stringify({ botToken: token, chatId }),
      });
      notify('Telegram settings saved');
      setTg(await api('/api/telegram/settings'));
      setShowTg(false);
    } catch (e) { notify(e.message, 'err'); }
    finally { setTgBusy(false); }
  };

  const testTg = async () => {
    setTgBusy(true);
    try {
      await api('/api/telegram/test', { method: 'POST' });
      notify('Test message sent - check the Telegram chat');
    } catch (e) { notify(e.message, 'err'); }
    finally { setTgBusy(false); }
  };

  const summaryText = () => {
    const today = new Date().toISOString().slice(0, 10);
    const lines = [
      '🎓 DDU - Institute of Technology',
      'Information Technology Invigilation Report',
      `📅 Generated: ${today}`,
      '',
      `• Total exams: ${stats ? stats.exams : exams.length} (Mid: ${stats ? stats.byType.Mid : '-'}, Final: ${stats ? stats.byType.Final : '-'})`,
      `• Invigilation assignments: ${stats ? stats.assignments : assigns.length}`,
      `• Positions filled: ${stats ? stats.filled : '-'} / ${stats ? stats.required : '-'}`,
      `• Exams fully covered: ${stats ? stats.fullyAssigned : '-'} / ${stats ? stats.exams : exams.length}`,
      '',
      'Per batch:',
      ...(stats ? stats.byBatch.map((b) => `  - ${b.batch}: ${b.exams} exams, ${b.assignments} assignments`) : []),
      '',
      `Invigilators on duty: ${perInv.length}`,
      ...perInv.slice(0, 15).map((v) => `  • ${v.name} (${v.dept || v.staffId}) - ${v.total} exam(s)`),
      ...(perInv.length > 15 ? [`  ...and ${perInv.length - 15} more (full list in the Excel report)`] : []),
    ];
    return lines.join('\n');
  };

  const sendTextTg = async () => {
    setTgBusy(true);
    try {
      await api('/api/telegram/send-text', {
        method: 'POST', body: JSON.stringify({ text: summaryText() }),
      });
      notify('Summary sent to Telegram');
    } catch (e) { notify(e.message, 'err'); }
    finally { setTgBusy(false); }
  };

  const sendFileTg = async () => {
    setTgBusy(true);
    try {
      const { wb, name } = buildWorkbook();
      const b64 = XLSX.write(wb, { type: 'base64', bookType: 'xlsx' });
      await api('/api/telegram/send-file', {
        method: 'POST',
        body: JSON.stringify({ filename: name, base64: b64,
          caption: 'DDU-IT Invigilation Assignment Report (all assigned invigilators)' }),
      });
      notify('Excel report sent to Telegram');
    } catch (e) { notify(e.message, 'err'); }
    finally { setTgBusy(false); }
  };

  const shareLink = () => {
    const url = 'https://t.me/share/url?url='
      + encodeURIComponent('http://localhost:5050') + '&text=' + encodeURIComponent(summaryText());
    window.open(url, '_blank');
  };

  /* ---------- render ---------- */
  return (
    <div>
      <div className="page-title">Reports & Sharing</div>
      <div className="page-sub">All assigned invigilators - filter, download as one file, or share to Telegram</div>

      <div className="card no-print">
        <div className="row">
          <select value={type} onChange={(e) => setType(e.target.value)} style={{ width: 150 }}>
            <option value="">All exam types</option>
            <option value="Mid">Mid exams</option>
            <option value="Final">Final exams</option>
          </select>
          <select value={batch} onChange={(e) => setBatch(e.target.value)} style={{ width: 210 }}>
            <option value="">All batches</option>
            {BATCHES.map((b) => <option key={b} value={b}>{b}</option>)}
          </select>
          <input type="text" placeholder="Search course, invigilator, room..." style={{ width: 240 }}
            value={q} onChange={(e) => setQ(e.target.value)} />
          <button className="btn gold" onClick={() => window.print()}>Print</button>
        </div>
      </div>

      <div className="card no-print">
        <h3>Download & share (one file with everything)</h3>
        <div className="row">
          <button className="btn primary" disabled={busy || rows.length === 0} onClick={downloadReport}>
            ⬇ Download Excel report
          </button>
          <button className="btn telegram" disabled={busy || rows.length === 0} onClick={sendFileTg}>
            📨 Send Excel file to Telegram
          </button>
          <button className="btn telegram" disabled={busy || assigns.length === 0} onClick={sendTextTg}>
            💬 Send summary to Telegram
          </button>
          <button className="btn" onClick={shareLink} title="Opens Telegram with the summary pre-filled">
            🔗 Open Telegram share
          </button>
          <button className="btn" onClick={openTgSettings}>⚙ Telegram settings {tg && tg.configured ? '✅' : ''}</button>
        </div>
        <p className="hint">
          The Excel report contains 3 sheets: All Assignments, By Invigilator and Summary.
          Telegram sending uses a department bot - configure it once in Telegram settings.
        </p>
        {showTg && (
          <div className="tg-panel">
            <h4>Telegram bot settings</h4>
            <div className="fgrid">
              <div className="full">
                <label>Bot token (from @BotFather)</label>
                <input type="text" value={token} placeholder="123456789:AAF..."
                  onChange={(e) => setTgToken(e.target.value)} />
                {tg && tg.botTokenMasked && <p className="hint">Saved token: {tg.botTokenMasked} (enter a new one to replace)</p>}
              </div>
              <div className="full">
                <label>Chat ID (group or user)</label>
                <input type="text" value={chatId} placeholder="-1001234567890"
                  onChange={(e) => setTgChatId(e.target.value)} />
                {tg && tg.chatId && <p className="hint">Saved chat id: {tg.chatId}</p>}
              </div>
            </div>
            <p className="hint">
              How to get these: 1) message <b>@BotFather</b> → /newbot → copy the token.
              2) Add the bot to your department Telegram group (or message it once).
              3) Open <b>https://api.telegram.org/bot&lt;TOKEN&gt;/getUpdates</b> in a browser and copy the chat id from the response.
            </p>
            <div className="row" style={{ marginTop: 10 }}>
              <button className="btn primary" disabled={tgBusy} onClick={saveTg}>Save settings</button>
              <button className="btn" disabled={tgBusy} onClick={testTg}>Send test message</button>
              <button className="btn" onClick={() => setShowTg(false)}>Close</button>
            </div>
          </div>
        )}
      </div>

      <div className="print-area">
        <div className="print-title">Invigilation Assignment Report - {rows.length} assignment(s)</div>
        <div className="card" style={{ padding: 0 }}>
          {rows.length === 0 ? (
            <div className="empty">
              {assigns.length === 0
                ? 'No assignments yet - assign invigilators first.'
                : 'No assignments match the current filter.'}
            </div>
          ) : (
            <table>
              <thead><tr>
                <th>Date</th><th>Time</th><th>Course</th><th>Type</th><th>Batch</th>
                <th>Room</th><th>Invigilator</th><th>Staff ID</th><th>Role</th><th>Status</th>
              </tr></thead>
              <tbody>
                {rows.map((r, i) => (
                  <tr key={i}>
                    <td>{r.Date}</td>
                    <td className="time">{r['Start Time']} - {r['End Time']}</td>
                    <td><b>{r['Course Code']}</b> {r['Course Title']}</td>
                    <td><span className={'badge ' + r['Exam Type'].toLowerCase()}>{r['Exam Type']}</span></td>
                    <td>{r.Batch || '-'}</td>
                    <td>{r['Room / Venue']}</td>
                    <td><b>{r.Invigilator}</b></td>
                    <td>{r['Staff ID']}</td>
                    <td>{r.Role === 'Instructor'
                      ? <span className="badge instructor">Instructor</span>
                      : <span className="badge member">Member</span>}</td>
                    <td><span className={'badge ' + r.Status.toLowerCase()}>{r.Status}</span></td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </div>

        {perInv.length > 0 && (
          <div className="card" style={{ padding: 0 }}>
            <div className="table-title">Load per invigilator</div>
            <table>
              <thead><tr>
                <th>Invigilator</th><th>Staff ID</th><th>Department</th>
                <th>Total exams</th><th>As Instructor</th>
              </tr></thead>
              <tbody>
                {perInv.map((v) => (
                  <tr key={v.staffId + v.name}>
                    <td><b>{v.name}</b></td>
                    <td>{v.staffId}</td>
                    <td>{v.dept}</td>
                    <td><b>{v.total}</b></td>
                    <td>{v.instructor}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
}
