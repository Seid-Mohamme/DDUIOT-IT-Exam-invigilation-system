import { useState, useEffect } from 'react';
import api from '../services/api.js';
import Modal from '../components/Modal.jsx';

/* User Accounts - main admin (Department Head) only.
   Create and manage logins for every type of user:
   - Admin (Department Head)  : full control incl. this page + Telegram sharing
   - Exam Coordinator         : manages exams / invigilators / assignments / reports
   - Invigilator              : signs in and sees only their own exams, rooms, batches */
const ROLES = [
  { id: 'admin', label: 'Admin (Department Head)', desc: 'Full control - including user accounts and Telegram sharing' },
  { id: 'coordinator', label: 'Exam Coordinator', desc: 'Manages exams, invigilators, assignments and reports (no user accounts)' },
  { id: 'invigilator', label: 'Invigilator', desc: 'Signs in to see only their own assigned exams, rooms and batches' },
];
const roleLabel = (r) => (ROLES.find((x) => x.id === r) || ROLES[2]).label.split(' (')[0];

const EMPTY = { name: '', email: '', password: '', role: 'invigilator', invigilatorId: '' };

export default function Users({ user, notify }) {
  const [users, setUsers] = useState([]);
  const [invs, setInvs] = useState([]);
  const [search, setSearch] = useState('');

  /* create-account modal */
  const [modal, setModal] = useState(false);
  const [f, setF] = useState(EMPTY);
  const [saving, setSaving] = useState(false);

  /* edit-account modal */
  const [edit, setEdit] = useState(null);       // the user object being edited
  const [ef, setEf] = useState(EMPTY);
  const [updating, setUpdating] = useState(false);

  const load = () => Promise.all([
    api('/api/auth/users'),
    api('/api/invigilators').catch(() => []),
  ]).then(([u, i]) => { setUsers(u); setInvs(i); });
  useEffect(() => { load(); }, []);

  const set = (k) => (e) => setF({ ...f, [k]: e.target.value });
  const setE = (k) => (e) => setEf({ ...ef, [k]: e.target.value });

  const create = async () => {
    if (!f.email.trim() || f.password.length < 4) {
      notify('Email and a password of at least 4 characters are required', 'err'); return;
    }
    if (f.role === 'invigilator' && !f.invigilatorId) {
      notify('Select which invigilator this login belongs to', 'err'); return;
    }
    if (f.role !== 'invigilator' && !f.name.trim()) {
      notify('Full name is required', 'err'); return;
    }
    setSaving(true);
    try {
      await api('/api/auth/users', { method: 'POST', body: JSON.stringify({
        name: f.name.trim(),
        email: f.email.trim(),
        password: f.password,
        role: f.role,
        invigilatorId: f.role === 'invigilator' ? f.invigilatorId : undefined,
      }) });
      notify('Account created - ' + roleLabel(f.role) + ' can now sign in');
      setModal(false);
      setF(EMPTY);
      load();
    } catch (e) { notify(e.message, 'err'); }
    finally { setSaving(false); }
  };

  const openEdit = (u) => {
    setEdit(u);
    setEf({ name: u.name || '', email: u.email || '', password: '',
      role: u.role, invigilatorId: u.invigilatorId || '' });
  };

  const saveEdit = async () => {
    if (!ef.email.trim()) { notify('Email is required', 'err'); return; }
    if (ef.role === 'invigilator' && !ef.invigilatorId) {
      notify('Select which invigilator this login belongs to', 'err'); return;
    }
    setUpdating(true);
    try {
      await api('/api/auth/users/' + edit.id, { method: 'PUT', body: JSON.stringify({
        name: ef.name.trim(), email: ef.email.trim(), role: ef.role,
        invigilatorId: ef.role === 'invigilator' ? ef.invigilatorId : '',
      }) });
      notify('Account updated');
      setEdit(null);
      load();
    } catch (e) { notify(e.message, 'err'); }
    finally { setUpdating(false); }
  };

  const resetPw = async (u) => {
    const pw = window.prompt('New password for ' + u.email + ':');
    if (!pw) return;
    if (pw.length < 4) { notify('Password must be at least 4 characters', 'err'); return; }
    try { await api('/api/auth/users/' + u.id + '/password', { method: 'PUT', body: JSON.stringify({ password: pw }) });
      notify('Password reset for ' + u.email); }
    catch (e) { notify(e.message, 'err'); }
  };

  const toggleActive = async (u) => {
    try {
      await api('/api/auth/users/' + u.id, { method: 'PUT', body: JSON.stringify({ active: !u.active }) });
      notify(u.active ? 'Account disabled - ' + u.email + ' can no longer sign in' : 'Account enabled');
      load();
    } catch (e) { notify(e.message, 'err'); }
  };

  const del = async (u) => {
    if (!window.confirm('Delete the account ' + u.email + '?')) return;
    try { await api('/api/auth/users/' + u.id, { method: 'DELETE' }); notify('Account deleted'); load(); }
    catch (e) { notify(e.message, 'err'); }
  };

  const q = search.trim().toLowerCase();
  const shown = users.filter((u) => !q
    || String(u.name).toLowerCase().includes(q)
    || String(u.email).toLowerCase().includes(q)
    || String(u.role).includes(q)
    || String(u.invigilatorName || '').toLowerCase().includes(q));

  return (
    <div>
      <div className="page-title">User Accounts</div>
      <div className="page-sub">
        Create and manage logins for the Department Head (admin), exam coordinators and departmental invigilators
      </div>

      <div className="card no-print">
        <div className="row">
          <button className="btn primary" onClick={() => { setF(EMPTY); setModal(true); }}>+ Create account</button>
          <input type="text" placeholder="Search name, email, role..." style={{ width: 240 }}
            value={search} onChange={(e) => setSearch(e.target.value)} />
          <span className="hint">{users.length} account(s)</span>
        </div>
      </div>

      <div className="card" style={{ padding: 0 }}>
        {shown.length === 0
          ? <div className="empty">{users.length === 0 ? 'No accounts yet - create the first one.' : 'No account matches the search.'}</div>
          : (
            <table>
              <thead><tr>
                <th>Name</th><th>Email</th><th>Role</th><th>Linked invigilator</th>
                <th>Status</th><th className="no-print">Actions</th>
              </tr></thead>
              <tbody>
                {shown.map((u) => (
                  <tr key={u.id} className={u.active ? '' : 'row-off'}>
                    <td><b>{u.name}</b>{u.id === user.id && <span className="hint"> (you)</span>}</td>
                    <td>{u.email}</td>
                    <td><span className={'badge role-' + u.role}>{roleLabel(u.role)}</span></td>
                    <td>{u.role === 'invigilator' ? (u.invigilatorName || '-') : '-'}</td>
                    <td><span className={'badge ' + (u.active ? 'on' : 'off')}>{u.active ? 'Active' : 'Disabled'}</span></td>
                    <td className="actions no-print">
                      <button className="btn sm" onClick={() => openEdit(u)}>Edit</button>
                      <button className="btn sm" onClick={() => resetPw(u)}>Reset password</button>
                      {u.id !== user.id && (
                        <button className="btn sm" onClick={() => toggleActive(u)}>{u.active ? 'Disable' : 'Enable'}</button>
                      )}
                      {u.id !== user.id && (
                        <button className="btn sm danger" onClick={() => del(u)}>Delete</button>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
      </div>

      <div className="card">
        <h3>What each role can do</h3>
        <table>
          <thead><tr><th>Role</th><th>Access</th></tr></thead>
          <tbody>
            {ROLES.map((r) => (
              <tr key={r.id}><td><span className={'badge role-' + r.id}>{r.label}</span></td><td>{r.desc}</td></tr>
            ))}
          </tbody>
        </table>
        <p className="hint" style={{ marginTop: 10 }}>
          Tip: an invigilator login must be linked to one invigilator from the Invigilators tab -
          that is how the system knows which exams, rooms and batches to show them.
          You cannot change the role or disable the account you are currently logged in with.
        </p>
      </div>

      {modal && (
        <Modal title="Create account" onClose={() => setModal(false)}>
          <div className="fgrid">
            <div className="full">
              <label>Role *</label>
              <select value={f.role} onChange={set('role')}>
                {ROLES.map((r) => <option key={r.id} value={r.id}>{r.label}</option>)}
              </select>
              <p className="hint">{ROLES.find((r) => r.id === f.role).desc}</p>
            </div>
            {f.role === 'invigilator' && (
              <div className="full">
                <label>Which invigilator is this login for? *</label>
                <select value={f.invigilatorId} onChange={set('invigilatorId')}>
                  <option value="">- select invigilator -</option>
                  {invs.map((v) => <option key={v._id} value={v._id}>{v.name} ({v.staffId})</option>)}
                </select>
                <p className="hint">The name is filled from the invigilator automatically.</p>
              </div>
            )}
            {f.role !== 'invigilator' && (
              <div className="full">
                <label>Full name *</label>
                <input type="text" value={f.name} onChange={set('name')} placeholder="e.g. Department Head" />
              </div>
            )}
            <div><label>Email (used to login) *</label>
              <input type="email" value={f.email} onChange={set('email')} placeholder="name@ddu.edu.et" /></div>
            <div><label>Password (min 4 characters) *</label>
              <input type="text" value={f.password} onChange={set('password')} placeholder="e.g. exam2026" /></div>
          </div>
          <div className="mfoot">
            <button className="btn" onClick={() => setModal(false)}>Cancel</button>
            <button className="btn primary" disabled={saving} onClick={create}>
              {saving ? 'Creating...' : 'Create account'}
            </button>
          </div>
        </Modal>
      )}

      {edit && (
        <Modal title={'Edit account - ' + edit.email} onClose={() => setEdit(null)}>
          <div className="fgrid">
            <div className="full">
              <label>Role</label>
              <select value={ef.role} onChange={setE('role')} disabled={edit.id === user.id}>
                {ROLES.map((r) => <option key={r.id} value={r.id}>{r.label}</option>)}
              </select>
              {edit.id === user.id && <p className="hint">You cannot change the role of the account you are logged in with.</p>}
            </div>
            {ef.role === 'invigilator' && (
              <div className="full">
                <label>Linked invigilator *</label>
                <select value={ef.invigilatorId} onChange={setE('invigilatorId')}>
                  <option value="">- select invigilator -</option>
                  {invs.map((v) => <option key={v._id} value={v._id}>{v.name} ({v.staffId})</option>)}
                </select>
              </div>
            )}
            <div><label>Full name</label>
              <input type="text" value={ef.name} onChange={setE('name')} /></div>
            <div><label>Email (used to login)</label>
              <input type="email" value={ef.email} onChange={setE('email')} /></div>
          </div>
          <div className="mfoot">
            <button className="btn" onClick={() => setEdit(null)}>Cancel</button>
            <button className="btn primary" disabled={updating} onClick={saveEdit}>
              {updating ? 'Saving...' : 'Save changes'}
            </button>
          </div>
        </Modal>
      )}
    </div>
  );
}
