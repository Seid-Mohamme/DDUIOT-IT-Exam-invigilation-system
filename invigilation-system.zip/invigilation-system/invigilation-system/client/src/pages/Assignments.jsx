import { useMemo, useState, useEffect } from 'react';
import api from '../services/api.js';
import Modal from '../components/Modal.jsx';
import { fmtDate, fmtTime, toMin } from '../utils/helpers.js';

export default function Assignments({ exams, invs, assigns, run, busy }) {
  const [edit, setEdit] = useState(null);       // assignment object being changed
  const [suggest, setSuggest] = useState(null); // exam object for the Suggest panel
  const [missedRecords, setMissedRecords] = useState([]);
  const [missedFor, setMissedFor] = useState(null); // assignment to mark as missed
  const [missedNote, setMissedNote] = useState('');

  const loadMissed = () => api('/api/missed').then(setMissedRecords).catch(() => {});
  useEffect(() => { loadMissed(); }, [assigns]);

  const openAbsences = missedRecords.filter((r) => r.status !== 'Closed');

  const recordMissed = async () => {
    if (!missedFor) return;
    try {
      await api('/api/missed', { method: 'POST', body: JSON.stringify({
        assignmentId: missedFor._id, note: missedNote.trim() }) });
      setMissedFor(null); setMissedNote('');
      loadMissed();
      run(() => Promise.resolve(), 'ABSENCE recorded - the department has been notified to REPLACE this invigilator');
    } catch (e) { alert(e.message); }
  };

  const perExam = useMemo(() => {
    const m = {};
    assigns.forEach((a) => { if (a.exam) (m[a.exam._id] = m[a.exam._id] || []).push(a); });
    return m;
  }, [assigns]);
  const loadMap = useMemo(() => {
    const m = {};
    assigns.forEach((a) => { if (a.invigilator) m[a.invigilator._id] = (m[a.invigilator._id] || 0) + 1; });
    return m;
  }, [assigns]);

  const byDate = useMemo(() => {
    const m = new Map();
    exams.forEach((e) => { if (!m.has(e.date)) m.set(e.date, []); m.get(e.date).push(e); });
    return [...m.entries()].sort((a, b) => (a[0] < b[0] ? -1 : 1));
  }, [exams]);

  /* ---------- conflict / availability helpers ---------- */

  /* the assignment of v that OVERLAPS this exam's date + time (double booking) */
  const conflictFor = (v, exam, excludeId) => assigns.find((a) =>
    a.invigilator && a.invigilator._id === v._id && a.exam && a._id !== excludeId &&
    a.exam.date === exam.date &&
    toMin(a.exam.startTime) < toMin(exam.endTime) &&
    toMin(exam.startTime) < toMin(a.exam.endTime));

  const onExam = (v, exam, excludeId) => (perExam[exam._id] || []).some((a) =>
    a.invigilator && a.invigilator._id === v._id && a._id !== excludeId);

  /* how many exams of THE SAME BATCH v already covers (batch rotation) */
  const batchTimes = (v, exam) => assigns.filter((a) =>
    a.invigilator && a.invigilator._id === v._id && a.exam &&
    exam.batch && a.exam.batch === exam.batch).length;

  /* free = not on this exam, under max load, no overlapped time that day */
  const isFree = (v, exam, excludeId) =>
    !onExam(v, exam, excludeId) &&
    (loadMap[v._id] || 0) < (v.maxLoad || 4) &&
    !conflictFor(v, exam, excludeId);

  /* recommendation order: least load -> least same-batch -> name */
  const recommendOrder = (a, b, exam) =>
    (loadMap[a._id] || 0) - (loadMap[b._id] || 0) ||
    batchTimes(a, exam) - batchTimes(b, exam) ||
    String(a.name).localeCompare(String(b.name));

  const cycle = (a) => {
    const order = ['Assigned', 'Accepted', 'Declined'];
    const next = order[(order.indexOf(a.status) + 1) % 3];
    run(() => api('/api/assignments/' + a._id, { method: 'PATCH', body: JSON.stringify({ status: next }) }));
  };

  const assignNow = (exam, v) =>
    run(() => api('/api/assignments',
      { method: 'POST', body: JSON.stringify({ examId: exam._id, invigilatorId: v._id }) }),
      'Invigilator assigned - no time conflict');

  const totalRequired = exams.reduce((s, e) => s + (e.requiredInvigilators || 1), 0);
  const totalFilled = exams.reduce((s, e) =>
    s + Math.min((perExam[e._id] || []).length, e.requiredInvigilators || 1), 0);

  return (
    <div>
      <div className="page-title">Invigilation Assignments</div>
      <div className="page-sub">
        {totalFilled} of {totalRequired} invigilator positions filled - use "Change" to fix a wrong assignment
        or "Suggest" to see who is free
      </div>

      {/* ---- URGENT: absences that need a replacement ---- */}
      {openAbsences.length > 0 && (
        <div className="absence-banner no-print">
          <b>⛔ URGENT - absent invigilator(s) to replace ({openAbsences.length}):</b>
          {openAbsences.map((r) => (
            <div key={r._id} style={{ marginTop: 5 }}>
              {r.invigilator?.name} did NOT show up for <b>{r.exam?.courseCode}</b>
              {' '}({fmtDate(r.exam?.date)}, {fmtTime(r.exam?.startTime)} - {fmtTime(r.exam?.endTime)}{r.exam?.venue ? ', ' + r.exam?.venue : ''})
              {r.excuseText ? ' · reason submitted' : ' · no reason yet'}
              {' '}- open <b>✨ Suggest</b> on that exam and assign a free invigilator.
            </div>
          ))}
          Manage everything in <b>Absences &amp; Feedback</b>.
        </div>
      )}
      <div className="card no-print">
        <div className="row">
          <button className="btn primary" disabled={busy || exams.length === 0 || invs.length === 0}
            onClick={() => run(() => api('/api/assignments/auto', { method: 'POST' }),
              (r) => 'Auto-assigned ' + r.assigned + ' invigilator(s) - loads balanced and batches rotated across days'
                + (r.unfulfilled.length ? ' - WARNING: ' + r.unfulfilled.map((u) => u.courseCode + ' needs ' + u.missing + ' more').join('; ') : ''))}>
            Auto-assign all
          </button>
          <button className="btn danger" disabled={busy || assigns.length === 0}
            onClick={() => { if (window.confirm('Remove ALL assignments?')) run(() => api('/api/assignments', { method: 'DELETE' }), 'All assignments cleared'); }}>
            Clear all assignments
          </button>
          <button className="btn gold" onClick={() => window.print()}>Print</button>
        </div>
        <p className="hint">
          Auto-assign never double-books an invigilator and rotates the batches, so each invigilator
          gets different batches on different exam days. Manually assigning an invigilator who is
          already busy at that date &amp; time is blocked with a clear reminder.
        </p>
      </div>

      {exams.length === 0 ? <div className="card"><div className="empty">Add exams first - then assign invigilators here.</div></div> : (
        <div className="print-area">
          {byDate.map(([date, list]) => (
            <div key={date}>
              <div className="date-head">{fmtDate(date)}</div>
              {list.map((exam) => {
                const mine = perExam[exam._id] || [];
                const freeList = invs.filter((v) => v.active && isFree(v, exam))
                  .sort((a, b) => recommendOrder(a, b, exam));
                /* invigilators already booked at this exact date + time */
                const busyList = invs.filter((v) => v.active && !onExam(v, exam) && conflictFor(v, exam));

                return (
                  <div className="exam-block" key={exam._id}>
                    <div className="exam-line">
                      <span className="code">{exam.courseCode}</span>
                      <span>{exam.courseTitle}</span>
                      {exam.batch && <span className="time">{exam.batch}</span>}
                      {exam.section && <span className="time">{exam.section}</span>}
                      <span className={'badge ' + exam.examType.toLowerCase()}>{exam.examType}</span>
                      <span className="time">{fmtTime(exam.startTime)} - {fmtTime(exam.endTime)}</span>
                      {exam.venue && <span className="time">{exam.venue}</span>}
                      <span className="no-print">
                        <button className="btn sm gold" onClick={() => setSuggest(exam)}
                          title="Who is free at this time? Who is overlapped?">
                          ✨ Suggest
                        </button>
                      </span>
                      <span className="time" style={{ marginLeft: 'auto', fontWeight: 700,
                        color: mine.length >= (exam.requiredInvigilators || 1) ? 'var(--green)' : 'var(--amber)' }}>
                        {mine.length} / {exam.requiredInvigilators}
                      </span>
                    </div>

                    {busyList.length > 0 && (
                      <div className="warn-line no-print">
                        ⚠ Overlapped time: <b>{busyList.map((v) => v.name).join(', ')}</b>
                        {' '}already assigned at {fmtTime(exam.startTime)} - {fmtTime(exam.endTime)}.
                        Open <b>Suggest</b> to see free recommendations and their free times.
                      </div>
                    )}

                    <div>
                      {mine.map((a) => (
                        <span className="chip" key={a._id}>
                          <b>{a.invigilator.name}</b>
                          {a.role === 'Instructor' && <span className="badge instructor">Instructor</span>}
                          <em>{a.invigilator.department || a.invigilator.staffId}</em>
                          {a.checkInAt && <span className="badge accepted" title={new Date(a.checkInAt).toLocaleString('en-GB')}>In room</span>}
                          {a.runningConfirmedAt && <span className="badge accepted" title={new Date(a.runningConfirmedAt).toLocaleString('en-GB')}>Safe</span>}
                          <button className="st" title="Click to change status" onClick={() => cycle(a)}>
                            <span className={'badge ' + a.status.toLowerCase()}>{a.status}</span>
                          </button>
                          <button className="edit no-print" title="Change this assignment (wrong invigilator / role)"
                            onClick={() => setEdit(a)}>Change</button>
                          <button className="edit no-print" title="This invigilator MISSED the invigilation - record the absence"
                            onClick={() => { setMissedFor(a); setMissedNote(''); }}>Missed</button>
                          <button className="x no-print" title="Remove assignment"
                            onClick={() => run(() => api('/api/assignments/' + a._id, { method: 'DELETE' }))}>x</button>
                        </span>
                      ))}
                      {mine.length < (exam.requiredInvigilators || 1) && (
                        <span className="chip" style={{ borderStyle: 'dashed', color: 'var(--amber)', fontWeight: 700 }}>
                          {exam.requiredInvigilators - mine.length} more invigilator(s) needed
                        </span>
                      )}
                      <span className="no-print">
                        <select value="" style={{ width: 'auto', maxWidth: 340, padding: '5px 8px' }}
                          onChange={(e) => {
                            const v = freeList.find((x) => x._id === e.target.value);
                            e.target.value = '';
                            if (v) assignNow(exam, v);
                          }}>
                          <option value="">+ Assign invigilator...</option>
                          {freeList.map((v) => (
                            <option key={v._id} value={v._id}>
                              ✓ {v.name} ({v.department || v.staffId}) - {loadMap[v._id] || 0}/{v.maxLoad} exams
                              {exam.batch ? `, ${exam.batch}: ${batchTimes(v, exam)}x` : ''}
                            </option>
                          ))}
                          {busyList.map((v) => {
                            const c = conflictFor(v, exam);
                            return (
                              <option key={v._id} disabled
                                value={'_busy_' + v._id}>
                                ⚠ {v.name} - ALREADY ASSIGNED AT THIS TIME ({c.exam.courseCode} {fmtDate(c.exam.date)}, {fmtTime(c.exam.startTime)} - {fmtTime(c.exam.endTime)})
                              </option>
                            );
                          })}
                        </select>
                        {freeList.length === 0 && mine.length < (exam.requiredInvigilators || 1) && (
                          <em style={{ fontSize: 12, color: 'var(--muted)', marginLeft: 8 }}>
                            no free invigilator for this exam time - busy ones are blocked above
                          </em>
                        )}
                      </span>
                    </div>
                  </div>
                );
              })}
            </div>
          ))}
        </div>
      )}

      {edit && (
        <EditAssignmentModal
          assignment={edit}
          exams={exams} invs={invs} assigns={assigns}
          isFree={isFree} conflictFor={conflictFor} loadMap={loadMap} batchTimes={batchTimes}
          onClose={() => setEdit(null)}
          onSave={(payload, okMsg) => run(() => api('/api/assignments/' + edit._id,
            { method: 'PUT', body: JSON.stringify(payload) }), okMsg).then((r) => { if (r) setEdit(null); })}
        />
      )}

      {suggest && (
        <SuggestModal
          exam={suggest} exams={exams} invs={invs} assigns={assigns} loadMap={loadMap}
          onClose={() => setSuggest(null)}
          onAssign={(v) => assignNow(suggest, v)}
        />
      )}

      {missedFor && (
        <Modal title={'Record missed invigilation - ' + missedFor.invigilator.name} onClose={() => setMissedFor(null)}>
          <p className="hint" style={{ marginBottom: 10 }}>
            {missedFor.exam.courseCode} ({missedFor.exam.courseTitle}) | {fmtDate(missedFor.exam.date)} |{' '}
            {fmtTime(missedFor.exam.startTime)} - {fmtTime(missedFor.exam.endTime)} | {missedFor.exam.venue || 'TBA'}
          </p>
          <div className="warn-line">
            Recording the absence immediately notifies the department to REPLACE this invigilator,
            and the invigilator will be asked to submit the reason. The Department Head takes the
            measure in "Absences &amp; Feedback".
          </div>
          <div className="full" style={{ marginTop: 10 }}>
            <label>Coordinator note (optional)</label>
            <textarea rows="3" style={{ width: '100%', padding: 9, border: '1px solid var(--line)', borderRadius: 8, fontFamily: 'inherit' }}
              value={missedNote} onChange={(e) => setMissedNote(e.target.value)}
              placeholder="e.g. did not report to Room 201 until end time, phone unreachable..." />
          </div>
          <div className="mfoot">
            <button className="btn" onClick={() => setMissedFor(null)}>Cancel</button>
            <button className="btn danger" onClick={recordMissed}>⛔ Record absence &amp; notify</button>
          </div>
        </Modal>
      )}
    </div>
  );
}

/* Change a wrong assignment: swap the invigilator or the role (Instructor / Member).
   Invigilators already assigned at this date & time are clearly marked and disabled. */
function EditAssignmentModal({ assignment, invs, assigns, isFree, conflictFor, loadMap, batchTimes, onClose, onSave }) {
  const exam = assignment.exam;
  const [invId, setInvId] = useState(String(assignment.invigilator._id));
  const [role, setRole] = useState(assignment.role);

  const active = invs.filter((v) => v.active);
  const free = active.filter((v) => v._id === assignment.invigilator._id || isFree(v, exam, assignment._id));
  const busy = active.filter((v) => v._id !== assignment.invigilator._id &&
    !isFree(v, exam, assignment._id) && conflictFor(v, exam, assignment._id));

  const selectedBusy = busy.some((v) => v._id === invId);
  const save = () => {
    const changedPerson = invId !== String(assignment.invigilator._id);
    const changedRole = role !== assignment.role;
    if (!changedPerson && !changedRole) { onClose(); return; }
    onSave(
      changedPerson ? { invigilatorId: invId, role } : { role },
      changedPerson ? 'Assignment updated - invigilator replaced' : 'Assignment updated - role changed'
    );
  };

  return (
    <Modal title="Change assignment" onClose={onClose}>
      <p className="hint" style={{ marginBottom: 12 }}>
        {exam.courseCode} - {exam.courseTitle} | {fmtDate(exam.date)} | {fmtTime(exam.startTime)} -
        {fmtTime(exam.endTime)} | {exam.venue || 'No room set'}{exam.batch ? ' | ' + exam.batch : ''}
      </p>
      <div className="fgrid">
        <div className="full"><label>Invigilator</label>
          <select value={invId} onChange={(e) => setInvId(e.target.value)}>
            {free.sort((a, b) => (loadMap[a._id] || 0) - (loadMap[b._id] || 0) || a.name.localeCompare(b.name)).map((v) => (
              <option key={v._id} value={v._id}>
                {v.name === assignment.invigilator.name ? '(current) ' : ''}
                {v.name} ({v.department || v.staffId}) - {loadMap[v._id] || 0}/{v.maxLoad} exams
                {exam.batch ? `, ${exam.batch}: ${batchTimes(v, exam)}x` : ''}
              </option>
            ))}
            {busy.map((v) => {
              const c = conflictFor(v, exam, assignment._id);
              return (
                <option key={v._id} disabled value={v._id}>
                  ⚠ {v.name} - ALREADY ASSIGNED AT THIS TIME ({c.exam.courseCode}, {fmtTime(c.exam.startTime)} - {fmtTime(c.exam.endTime)})
                </option>
              );
            })}
          </select>
        </div>
        <div><label>Role</label>
          <select value={role} onChange={(e) => setRole(e.target.value)}>
            <option value="Instructor">Instructor (in-charge)</option>
            <option value="Member">Member</option>
          </select>
        </div>
      </div>
      {selectedBusy && (
        <div className="warn-line">
          ⚠ This invigilator is already assigned at that date &amp; time - the system will not allow the change.
        </div>
      )}
      <div className="mfoot">
        <button className="btn" onClick={onClose}>Cancel</button>
        <button className="btn primary" onClick={save} disabled={selectedBusy}>Save changes</button>
      </div>
    </Modal>
  );
}

/* ---------- SUGGEST PANEL ----------
   For one exam it identifies:
   1) invigilators free at this exam time  -> recommended (least load first, then
      those who covered this batch the fewest times, so batches rotate across days)
   2) invigilators ALREADY ASSIGNED at this time (overlap) -> each one's clashing
      exam AND the other exam sessions where this invigilator is still free.  */
function SuggestModal({ exam, exams, invs, assigns, loadMap, onClose, onAssign }) {
  const assignedTo = (v, e2) => assigns.some((a) =>
    a.invigilator && a.invigilator._id === v._id && a.exam && a.exam._id === e2._id);
  const conflictFor = (v) => assigns.find((a) =>
    a.invigilator && a.invigilator._id === v._id && a.exam &&
    a.exam.date === exam.date &&
    toMin(a.exam.startTime) < toMin(exam.endTime) &&
    toMin(exam.startTime) < toMin(a.exam.endTime));
  const batchTimes = (v) => assigns.filter((a) =>
    a.invigilator && a.invigilator._id === v._id && a.exam &&
    exam.batch && a.exam.batch === exam.batch).length;

  const mine = assigns.filter((a) => a.exam && a.exam._id === exam._id).length;
  const needed = Math.max(0, (exam.requiredInvigilators || 1) - mine);

  /* free at this time - recommended */
  const free = invs
    .filter((v) => v.active && !assignedTo(v, exam) && !conflictFor(v) &&
      (loadMap[v._id] || 0) < (v.maxLoad || 4))
    .sort((a, b) => (loadMap[a._id] || 0) - (loadMap[b._id] || 0) ||
      batchTimes(a) - batchTimes(b) || String(a.name).localeCompare(String(b.name)));

  /* overlapped at this time */
  const busy = invs.filter((v) => v.active && conflictFor(v));

  /* other exam sessions where a busy invigilator is still free
     (= their free date & time in this schedule) */
  const freeTimesFor = (v) => exams
    .filter((e) => e._id !== exam._id)
    .filter((e) => !assignedTo(v, e))
    .filter((e) => !assigns.some((a) =>
      a.invigilator && a.invigilator._id === v._id && a.exam &&
      a.exam.date === e.date &&
      toMin(a.exam.startTime) < toMin(e.endTime) && toMin(e.startTime) < toMin(a.exam.endTime)))
    .sort((x, y) => (x.date === y.date
      ? toMin(x.startTime) - toMin(y.startTime)
      : (x.date < y.date ? -1 : 1)))
    .slice(0, 4);

  return (
    <Modal title="Suggest invigilators for this exam" onClose={onClose}>
      <p className="hint" style={{ marginBottom: 12 }}>
        {exam.courseCode} - {exam.courseTitle} | {fmtDate(exam.date)} | {fmtTime(exam.startTime)} -
        {fmtTime(exam.endTime)} | {exam.venue || 'No room set'}{exam.batch ? ' | ' + exam.batch : ''}
        {' '}| <b>{needed}</b> more invigilator(s) needed
      </p>

      <h4 className="sug-h ok-h">✅ Recommended - free at this exam time</h4>
      {free.length === 0 ? (
        <p className="hint">Nobody is free at this time. Add more invigilators or move an exam time.</p>
      ) : free.slice(0, 8).map((v) => (
        <div className="sug-item" key={v._id}>
          <div>
            <b>{v.name}</b> <em>({v.department || v.staffId})</em>
            <div className="sug-meta">
              {loadMap[v._id] || 0}/{v.maxLoad} exams assigned
              {exam.batch ? ` · ${exam.batch}: covered ${batchTimes(v)}x so far` : ''}
            </div>
          </div>
          <button className="btn sm primary" onClick={() => onAssign(v)}>Assign</button>
        </div>
      ))}

      <h4 className="sug-h busy-h">⚠ Already assigned at this time (overlapped)</h4>
      {busy.length === 0 ? (
        <p className="hint">Nobody is double-booked for this exam time.</p>
      ) : busy.map((v) => {
        const c = conflictFor(v);
        const ft = freeTimesFor(v);
        return (
          <div className="sug-item sug-busy" key={v._id}>
            <div>
              <b>{v.name}</b> <em>({v.department || v.staffId})</em>
              <div className="sug-clash">
                ⚠ Busy with {c.exam.courseCode} on {fmtDate(c.exam.date)},
                {' '}{fmtTime(c.exam.startTime)} - {fmtTime(c.exam.endTime)}{c.exam.venue ? `, ${c.exam.venue}` : ''}
              </div>
              <div className="sug-meta">
                {ft.length
                  ? 'Free at: ' + ft.map((e) =>
                    `${fmtDate(e.date)} ${fmtTime(e.startTime)} - ${fmtTime(e.endTime)} (${e.courseCode})`).join('  |  ')
                  : 'No free exam session left in this schedule'}
              </div>
            </div>
          </div>
        );
      })}

      <div className="mfoot">
        <button className="btn" onClick={onClose}>Close</button>
      </div>
    </Modal>
  );
}
