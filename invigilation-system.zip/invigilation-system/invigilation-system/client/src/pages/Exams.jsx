import { useState, useMemo } from 'react';
import api from '../services/api.js';
import UploadModal from '../components/UploadModal.jsx';
import ExamModal from '../components/ExamModal.jsx';
import { fmtDate, fmtTime, dlTemplate } from '../utils/helpers.js';

export default function Exams({ exams, assigns, run, notify, busy }) {
  const [modal, setModal] = useState(null);   // 'new' | exam object
  const [upload, setUpload] = useState(false);
  const perExam = useMemo(() => {
    const m = {};
    assigns.forEach((a) => { if (a.exam) m[a.exam._id] = (m[a.exam._id] || 0) + 1; });
    return m;
  }, [assigns]);

  return (
    <div>
      <div className="page-title">Exam Schedule</div>
      <div className="page-sub">Mid and final exam sessions - add manually or upload from Excel/CSV</div>
      <div className="card no-print">
        <div className="row">
          <button className="btn primary" onClick={() => setModal('new')}>+ Add exam</button>
          <button className="btn gold" onClick={() => setUpload(true)}>Upload Excel / CSV</button>
          <button className="btn" onClick={() => dlTemplate('exam')}>Download template</button>
          <button className="btn danger" disabled={busy || exams.length === 0}
            onClick={() => { if (window.confirm('Delete ALL exams (and their assignments)?')) run(() => api('/api/exams', { method: 'DELETE' }), 'All exams deleted'); }}>
            Delete all
          </button>
        </div>
      </div>
      <div className="card" style={{ padding: 0 }}>
        {exams.length === 0 ? <div className="empty">No exams yet - add one or upload the exam schedule file.</div> : (
          <table>
            <thead><tr>
              <th>Date</th><th>Time</th><th>Course</th><th>Batch</th><th>Section</th><th>Type</th>
              <th>Venue</th><th>Students</th><th>Invigilators</th><th className="no-print">Actions</th>
            </tr></thead>
            <tbody>
              {exams.map((e) => (
                <tr key={e._id}>
                  <td><b>{fmtDate(e.date)}</b></td>
                  <td className="time">{fmtTime(e.startTime)} - {fmtTime(e.endTime)}</td>
                  <td><b>{e.courseCode}</b><br /><span style={{ color: 'var(--muted)', fontSize: 12 }}>{e.courseTitle}</span></td>
                  <td style={{ fontSize: 12.5 }}>{e.batch || '-'}</td>
                  <td>{e.section}</td>
                  <td><span className={'badge ' + e.examType.toLowerCase()}>{e.examType}</span></td>
                  <td>{e.venue}</td>
                  <td>{e.studentsCount}</td>
                  <td><b>{perExam[e._id] || 0}</b> / {e.requiredInvigilators}</td>
                  <td className="actions no-print">
                    <button className="btn sm" onClick={() => setModal(e)}>Edit</button>
                    <button className="btn sm danger" onClick={() => {
                      if (window.confirm('Delete ' + e.courseCode + ' on ' + e.date + '?'))
                        run(() => api('/api/exams/' + e._id, { method: 'DELETE' }), 'Exam deleted');
                    }}>Delete</button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
      {modal && (
        <ExamModal
          exam={modal === 'new' ? null : modal}
          onClose={() => setModal(null)}
          onSave={(f) => run(
            () => modal === 'new'
              ? api('/api/exams', { method: 'POST', body: JSON.stringify(f) })
              : api('/api/exams/' + modal._id, { method: 'PUT', body: JSON.stringify(f) }),
            modal === 'new' ? 'Exam added' : 'Exam updated'
          ).then(() => setModal(null))}
        />
      )}
      {upload && <UploadModal kind="exam" onClose={() => setUpload(false)}
        onDone={(res) => { setUpload(false); notify('Imported ' + res.imported + ' exam(s)'
          + (res.errors.length ? ' - skipped: ' + res.errors.slice(0, 3).join(' | ') : ''), res.errors.length ? 'warn' : 'ok'); run(() => Promise.resolve()); }} />}
    </div>
  );
}
