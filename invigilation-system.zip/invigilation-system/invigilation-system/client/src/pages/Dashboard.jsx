import api from '../services/api.js';

export default function Dashboard({ stats, run, go, busy }) {
  if (!stats) return null;
  const pct = stats.required ? Math.round((stats.filled / stats.required) * 100) : 0;
  const isEmpty = stats.exams === 0 && stats.invigilators === 0;
  return (
    <div>
      <div className="page-title">Dashboard</div>
      <div className="page-sub">Invigilator assignment overview - mid and final exams</div>
      <div className="grid4">
        <div className="stat"><div className="n">{stats.exams}</div><div className="l">Total exams</div></div>
        <div className="stat"><div className="n">{stats.invigilators}</div><div className="l">Invigilators</div></div>
        <div className="stat">
          <div className="n">{stats.filled} / {stats.required}</div><div className="l">Invigilator positions filled</div>
          <div className="bar"><i style={{ width: pct + '%' }} /></div>
        </div>
        <div className="stat"><div className="n">{stats.fullyAssigned} / {stats.exams}</div>
          <div className="l">Exams fully covered</div></div>
      </div>

      {stats.byBatch && stats.byBatch.length > 0 && (
        <div className="card">
          <h3>Exams per batch</h3>
          <div className="row">
            {stats.byBatch.map((b) => (
              <span className="chip" key={b.batch} style={{ fontSize: 13 }}>
                <b>{b.batch}</b><em>{b.exams} exam(s), {b.assignments} assignment(s)</em>
              </span>
            ))}
          </div>
        </div>
      )}

      <div className="card no-print">
        <h3>Quick actions</h3>
        <div className="row">
          <button className="btn primary" disabled={busy || stats.exams === 0}
            onClick={() => run(() => api('/api/assignments/auto', { method: 'POST' }),
              (r) => 'Auto-assigned ' + r.assigned + ' invigilator(s) - loads balanced, batches rotated across days'
                + (r.unfulfilled.length ? ' - WARNING: ' + r.unfulfilled.length + ' exam(s) still short of staff' : ''))}>
            Auto-assign invigilators
          </button>
          <button className="btn" disabled={busy || stats.assignments === 0}
            onClick={() => { if (window.confirm('Remove ALL assignments?')) run(() => api('/api/assignments', { method: 'DELETE' }), 'All assignments cleared'); }}>
            Clear all assignments
          </button>
          <button className="btn" onClick={() => go('exams')}>Exam schedule</button>
          <button className="btn" onClick={() => go('assignments')}>View assignments</button>
          <button className="btn" onClick={() => go('reports')}>Reports & share</button>
        </div>
      </div>

      {isEmpty && (
        <div className="card">
          <h3>Get started</h3>
          <ol className="steps">
            <li><b>Option A (try it):</b> click "Load sample data" below, then "Auto-assign invigilators".</li>
            <li><b>Option B (your data):</b> open "Exam Schedule" and "Invigilators" tabs - add manually or upload an Excel/CSV file (a template can be downloaded there).</li>
            <li>Click "Auto-assign invigilators" - the system distributes invigilators fairly with no time clashes.</li>
            <li>Fine-tune manually in "Assignments": add, remove, change status (Assigned / Accepted / Declined) or fix a wrong assignment with "Change".</li>
            <li>Open "Reports & Share" to download all assigned invigilators as one Excel file or send them to your Telegram group.</li>
          </ol>
          <div className="row" style={{ marginTop: 10 }}>
            <button className="btn gold" disabled={busy}
              onClick={() => run(() => api('/api/sample', { method: 'POST' }), 'Sample data loaded - now click Auto-assign')}>
              Load sample data
            </button>
          </div>
        </div>
      )}

      {!isEmpty && stats.filled < stats.required && (
        <div className="card" style={{ borderLeft: '4px solid var(--amber)' }}>
          <h3>Attention</h3>
          <p className="hint" style={{ fontSize: 13 }}>
            {stats.required - stats.filled} invigilator position(s) are not yet covered across the total exams.
            Either run Auto-assign again, add more invigilators, or lower "Required Invigilators" on some exams.
          </p>
        </div>
      )}
    </div>
  );
}
