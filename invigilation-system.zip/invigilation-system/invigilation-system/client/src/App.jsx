import { useState, useEffect } from 'react';
import api, { getToken, setToken, onUnauthorized } from './services/api.js';
import Toast from './components/Toast.jsx';
import Login from './pages/Login.jsx';
import Dashboard from './pages/Dashboard.jsx';
import Exams from './pages/Exams.jsx';
import Invigilators from './pages/Invigilators.jsx';
import Assignments from './pages/Assignments.jsx';
import Reports from './pages/Reports.jsx';
import MyExams from './pages/MyExams.jsx';
import Users from './pages/Users.jsx';
import Incidents from './pages/Incidents.jsx';
import NotificationBell from './components/NotificationBell.jsx';

/* Department Head (admin) + Exam Coordinator share these tabs */
const STAFF_TABS = [
  { id: 'dashboard', label: 'Dashboard' },
  { id: 'exams', label: 'Exam Schedule' },
  { id: 'invigilators', label: 'Invigilators' },
  { id: 'assignments', label: 'Assignments' },
  { id: 'incidents', label: 'Absences & Feedback' },
  { id: 'reports', label: 'Reports & Share' },
];
/* only the main admin (Department Head) can manage user accounts */
const USERS_TAB = [{ id: 'users', label: 'User Accounts' }];

const INVIGILATOR_TABS = [
  { id: 'myexams', label: 'My Exams' },
];

/* role badge shown ONCE next to the user name in the navbar -
   short labels, never repeated */
const roleLabel = (role) =>
  role === 'admin' ? 'Admin' : role === 'coordinator' ? 'Exam Coordinator' : 'Invigilator';

export default function App() {
  const [user, setUser] = useState(null);        // null = not logged in
  const [checking, setChecking] = useState(true);
  const [tab, setTab] = useState('dashboard');
  const [exams, setExams] = useState([]);
  const [invs, setInvs] = useState([]);
  const [assigns, setAssigns] = useState([]);
  const [stats, setStats] = useState(null);
  const [toast, setToast] = useState(null);
  const [busy, setBusy] = useState(false);

  const notify = (msg, kind = 'ok') => {
    setToast({ msg, kind });
    setTimeout(() => setToast(null), 4500);
  };

  const isAdmin = user && user.role === 'admin';
  const isStaff = user && (user.role === 'admin' || user.role === 'coordinator');

  /* load all data (staff home) - invigilators only need their own exams */
  const reload = async () => {
    if (!user) return;
    if (isStaff) {
      const [e, i, a, s] = await Promise.all([
        api('/api/exams'),
        api('/api/invigilators'),
        api('/api/assignments'),
        api('/api/stats/summary'),
      ]);
      setExams(e); setInvs(i); setAssigns(a); setStats(s);
    } else {
      const a = await api('/api/assignments/mine');
      setAssigns(a);
    }
  };

  const run = async (fn, okMsg) => {
    setBusy(true);
    try {
      const r = await fn();
      await reload();
      if (okMsg) notify(typeof okMsg === 'function' ? okMsg(r) : okMsg);
      return r;
    } catch (e) { notify(e.message, 'err'); }
    finally { setBusy(false); }
  };

  /* restore the session on page reload */
  useEffect(() => {
    onUnauthorized(() => { setUser(null); notify('Session expired - please login again', 'warn'); });
    if (!getToken()) { setChecking(false); return; }
    api('/api/auth/me')
      .then((u) => { setUser(u); setTab(u.role === 'admin' || u.role === 'coordinator' ? 'dashboard' : 'myexams'); })
      .catch(() => {})
      .finally(() => setChecking(false));
  }, []);

  useEffect(() => { if (user) reload().catch((e) => notify(e.message, 'err')); }, [user]);

  const handleLogin = ({ token, user: u }) => {
    setToken(token);
    setUser(u);
    setTab(u.role === 'admin' || u.role === 'coordinator' ? 'dashboard' : 'myexams');
  };

  const logout = () => {
    setToken(null);
    setUser(null);
    setExams([]); setInvs([]); setAssigns([]); setStats(null);
  };

  if (checking) return <div className="boot">Loading...</div>;
  if (!user) return <Login onLogin={handleLogin} />;

  const tabs = isStaff
    ? (isAdmin ? [...STAFF_TABS, ...USERS_TAB] : STAFF_TABS)
    : INVIGILATOR_TABS;

  return (
    <div>
      <div className="topbar no-print">
        <div className="brand">
          {/* logo file lives at invigilation-system/images/logo.jpg (copied to client/public) */}
          <img src="/logo.jpg" alt="Dire Dawa University logo" className="logo-img" />
          <div className="brand-text">
            <h1>Dire Dawa University - Institute of Technology</h1>
            <h2>Information Technology Invigilation System</h2>
          </div>
        </div>
        <nav className="mainnav">
          {tabs.map((t) => (
            <button key={t.id} className={tab === t.id ? 'active' : ''} onClick={() => setTab(t.id)}>
              {t.label}
            </button>
          ))}
        </nav>
        {/* logged-in user + Logout pinned in the RIGHT corner of the banner.
            Role badge and name are each displayed exactly once. */}
        <div className="user-box">
          <span className="user-role">{roleLabel(user.role)}</span>
          <span className="user-name" title={user.email}>{user.name}</span>
          <NotificationBell user={user} />
          <button className="btn sm logout" onClick={logout}>Logout</button>
        </div>
      </div>

      <div className="wrap">
        {isStaff && tab === 'dashboard' && <Dashboard stats={stats} run={run} go={setTab} busy={busy} />}
        {isStaff && tab === 'exams' && <Exams exams={exams} assigns={assigns} run={run} notify={notify} busy={busy} />}
        {isStaff && tab === 'invigilators' && <Invigilators invs={invs} assigns={assigns} run={run} notify={notify} busy={busy} user={user} />}
        {isStaff && tab === 'assignments' && <Assignments exams={exams} invs={invs} assigns={assigns} run={run} busy={busy} />}
        {isStaff && tab === 'incidents' && <Incidents user={user} run={run} notify={notify} busy={busy} />}
        {isStaff && tab === 'reports' && <Reports exams={exams} invs={invs} assigns={assigns} stats={stats} run={run} notify={notify} busy={busy} user={user} />}
        {isAdmin && tab === 'users' && <Users user={user} notify={notify} />}
        {!isStaff && tab === 'myexams' && <MyExams user={user} assigns={assigns} reload={reload} notify={notify} />}
      </div>

      <Toast toast={toast} />
    </div>
  );
}
