/* API client - all backend communication goes through here.
   Adds the JWT token to every request and handles session expiry. */
const TOKEN_KEY = 'ddu_invig_token';

export const getToken = () => localStorage.getItem(TOKEN_KEY);
export const setToken = (t) => {
  if (t) localStorage.setItem(TOKEN_KEY, t);
  else localStorage.removeItem(TOKEN_KEY);
};

/* App.jsx registers a handler: when any API call returns 401 the user
   is sent back to the login screen. */
let unauthorizedHandler = null;
export const onUnauthorized = (fn) => { unauthorizedHandler = fn; };

const api = async (url, opts = {}) => {
  const headers = { 'Content-Type': 'application/json', ...(opts.headers || {}) };
  const token = getToken();
  if (token) headers.Authorization = 'Bearer ' + token;

  const res = await fetch(url, { ...opts, headers });
  const data = await res.json().catch(() => ({}));

  if (res.status === 401) {
    setToken(null);
    if (unauthorizedHandler) unauthorizedHandler();
  }
  if (!res.ok) throw new Error(data.message || `Request failed (${res.status})`);
  return data;
};

export default api;
