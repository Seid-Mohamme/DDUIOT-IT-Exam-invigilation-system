import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

// dev server on 5174 (does not clash with other projects on 5173)
// /api requests are proxied to the backend on port 5050
// publicDir -> invigilation-system/images : every file in that folder is
// served at "/" (e.g. /logo.jpg) and copied into dist on build
export default defineConfig({
  plugins: [react()],
  publicDir: '../images',
  server: {
    port: 5174,
    proxy: {
      '/api': 'http://localhost:5050',
    },
  },
});
