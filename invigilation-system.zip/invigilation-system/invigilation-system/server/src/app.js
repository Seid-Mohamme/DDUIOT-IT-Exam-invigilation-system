/* Express app - routes and middleware */
const path = require('path');
const fs = require('fs');
const express = require('express');
const cors = require('cors');

const app = express();

app.use(cors());
app.use(express.json({ limit: '15mb' }));   // allows base64 Excel reports for Telegram

/* API routes */
app.get('/api/health', (req, res) => res.json({ ok: true }));
app.use('/api/auth', require('./routes/authRoutes'));
app.use('/api/telegram', require('./routes/telegramRoutes'));
app.use('/api', require('./routes/statsRoutes'));
app.use('/api/exams', require('./routes/examRoutes'));
app.use('/api/invigilators', require('./routes/invigilatorRoutes'));
app.use('/api/assignments', require('./routes/assignmentRoutes'));
app.use('/api/missed', require('./routes/missedRoutes'));
app.use('/api/notifications', require('./routes/notificationRoutes'));
app.use('/api/feedback', require('./routes/feedbackRoutes'));

/* Serve the built frontend if it exists (production mode) */
const distIndex = path.join(__dirname, '..', '..', 'client', 'dist', 'index.html');
app.use(express.static(path.join(distIndex, '..')));
app.get('*', (req, res) => {
  if (req.path.startsWith('/api/')) return res.status(404).json({ message: 'Not found' });
  if (fs.existsSync(distIndex)) return res.sendFile(distIndex);
  res.status(200).send(
    '<h2 style="font-family:sans-serif">Invigilation System - backend is running</h2>' +
    '<p style="font-family:sans-serif">The frontend is not built yet. For development run ' +
    '<b>npm run dev</b> from the project root and open <b>http://localhost:5174</b>.</p>' +
    '<p style="font-family:sans-serif">Or build it: <b>npm run build --prefix client</b>, then restart the server.</p>'
  );
});

/* Central error handler */
app.use((err, req, res, next) => { // eslint-disable-line no-unused-vars
  console.error('[ERROR]', err.message);
  const msg = err.code === 11000
    ? 'Duplicate value: ' + Object.values(err.keyValue || {}).join(', ')
    : err.message;
  res.status(err.status || (err.code === 11000 ? 400 : 500)).json({ message: msg });
});

module.exports = app;
