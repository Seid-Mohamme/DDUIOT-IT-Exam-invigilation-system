const mongoose = require('mongoose');

/* Login accounts.
   role 'admin'       -> Department Head (main admin): full control + user accounts + Telegram sharing
   role 'coordinator' -> Exam coordinator: manages exams/assignments/reports, cannot manage user accounts
   role 'invigilator' -> Departmental invigilator: sees only their own assigned exams */
const userSchema = new mongoose.Schema({
  name:         { type: String, required: true, trim: true },
  email:        { type: String, required: true, unique: true, lowercase: true, trim: true },
  passwordHash: { type: String, required: true },
  role:         { type: String, enum: ['admin', 'coordinator', 'invigilator'], default: 'invigilator' },
  invigilator:  { type: mongoose.Schema.Types.ObjectId, ref: 'Invigilator', default: null },
  active:       { type: Boolean, default: true },
}, { timestamps: true });

module.exports = mongoose.model('User', userSchema);
