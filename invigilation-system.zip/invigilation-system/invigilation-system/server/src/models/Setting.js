const mongoose = require('mongoose');

/* Simple key/value store for system settings (Telegram bot token, chat id, ...) */
const settingSchema = new mongoose.Schema({
  key:      { type: String, unique: true, default: 'telegram' },
  botToken: { type: String, default: '' },
  chatId:   { type: String, default: '' },
}, { timestamps: true });

module.exports = mongoose.model('Setting', settingSchema);
