const mongoose = require('mongoose');

/* A recorded absence: the exam coordinator marks an assignment as "missed
   invigilation". The invigilator then submits WHY (excuse), and the
   Department Head takes the final measure. */
const missedSchema = new mongoose.Schema({
  assignment:  { type: mongoose.Schema.Types.ObjectId, ref: 'Assignment', required: true, unique: true },
  exam:        { type: mongoose.Schema.Types.ObjectId, ref: 'Exam', required: true },
  invigilator: { type: mongoose.Schema.Types.ObjectId, ref: 'Invigilator', required: true },
  note:        { type: String, default: '' },           // why the coordinator recorded it
  reportedBy:  { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
  excuseText:  { type: String, default: '' },           // the invigilator's reason
  excuseAt:    { type: Date, default: null },
  actionTaken: { type: String, default: '' },           // measure taken by the Department Head
  actionAt:    { type: Date, default: null },
  actionBy:    { type: mongoose.Schema.Types.ObjectId, ref: 'User', default: null },
  status:      { type: String, enum: ['Open', 'Explained', 'Closed'], default: 'Open' },
}, { timestamps: true });

module.exports = mongoose.model('MissedInvigilation', missedSchema);
