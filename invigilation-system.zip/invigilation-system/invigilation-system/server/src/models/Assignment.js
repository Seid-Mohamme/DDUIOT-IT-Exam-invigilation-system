const mongoose = require('mongoose');

const assignmentSchema = new mongoose.Schema({
  exam:        { type: mongoose.Schema.Types.ObjectId, ref: 'Exam', required: true },
  invigilator: { type: mongoose.Schema.Types.ObjectId, ref: 'Invigilator', required: true },
  role:        { type: String, enum: ['Instructor', 'Member'], default: 'Member' },
  status:      { type: String, enum: ['Assigned', 'Accepted', 'Declined'], default: 'Assigned' },
  checkInAt:         { type: Date, default: null },  // "I am in the exam room"
  runningConfirmedAt:{ type: Date, default: null },  // "the exam is running safely"
}, { timestamps: true });

// one invigilator can appear only once per exam
assignmentSchema.index({ exam: 1, invigilator: 1 }, { unique: true });

module.exports = mongoose.model('Assignment', assignmentSchema);
