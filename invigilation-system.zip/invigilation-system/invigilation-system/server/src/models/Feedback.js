const mongoose = require('mongoose');

/* Feedback sent by invigilators to the department */
const feedbackSchema = new mongoose.Schema({
  invigilator: { type: mongoose.Schema.Types.ObjectId, ref: 'Invigilator', required: true },
  exam:        { type: mongoose.Schema.Types.ObjectId, ref: 'Exam', default: null },
  assignment:  { type: mongoose.Schema.Types.ObjectId, ref: 'Assignment', default: null },
  category:    { type: String, enum: ['General', 'Issue', 'Suggestion', 'Other'], default: 'General' },
  message:     { type: String, required: true, trim: true },
}, { timestamps: true });

module.exports = mongoose.model('Feedback', feedbackSchema);
