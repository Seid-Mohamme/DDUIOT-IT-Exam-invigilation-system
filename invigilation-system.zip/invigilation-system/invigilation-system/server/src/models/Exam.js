const mongoose = require('mongoose');
const { BATCHES } = require('../utils/batches');

const examSchema = new mongoose.Schema({
  courseCode:   { type: String, required: true, uppercase: true, trim: true },
  courseTitle:  { type: String, default: '' },
  section:      { type: String, default: '' },
  batch:        { type: String, default: '', enum: [...BATCHES, ''] },
  examType:     { type: String, enum: ['Mid', 'Final'], default: 'Final' },
  date:         { type: String, required: true },   // YYYY-MM-DD
  startTime:    { type: String, required: true },   // HH:MM (24h)
  endTime:      { type: String, required: true },   // HH:MM (24h)
  venue:        { type: String, default: '' },
  studentsCount:{ type: Number, default: 0 },
  requiredInvigilators: { type: Number, default: 1, min: 1 },
}, { timestamps: true });

examSchema.statics.BATCHES = BATCHES;

module.exports = mongoose.model('Exam', examSchema);
