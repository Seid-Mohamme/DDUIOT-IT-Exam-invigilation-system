const mongoose = require('mongoose');

const invigilatorSchema = new mongoose.Schema({
  name:       { type: String, required: true, trim: true },
  staffId:    { type: String, required: true, unique: true, trim: true },
  department: { type: String, default: '' },
  email:      { type: String, default: '' },
  phone:      { type: String, default: '' },
  maxLoad:    { type: Number, default: 4, min: 1 },
  active:     { type: Boolean, default: true },
}, { timestamps: true });

module.exports = mongoose.model('Invigilator', invigilatorSchema);
