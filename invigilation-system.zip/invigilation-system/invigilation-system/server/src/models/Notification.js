const mongoose = require('mongoose');

/* In-app notifications.
   audience 'staff'      -> Department Head + Exam Coordinator (absence alerts, check-ins, feedback)
   audience 'invigilator'-> invigilator logins; if targetInvigilator is set only the
                            login(s) of THAT invigilator see it (e.g. measure taken) */
const notificationSchema = new mongoose.Schema({
  audience:         { type: String, enum: ['staff', 'invigilator'], required: true },
  targetInvigilator:{ type: mongoose.Schema.Types.ObjectId, ref: 'Invigilator', default: null },
  type:             { type: String, enum: ['absence', 'excuse', 'measure', 'checkin', 'safe', 'feedback', 'info'], default: 'info' },
  title:            { type: String, required: true },
  body:             { type: String, default: '' },
  examId:           { type: mongoose.Schema.Types.ObjectId, ref: 'Exam', default: null },
  assignmentId:     { type: mongoose.Schema.Types.ObjectId, ref: 'Assignment', default: null },
  urgent:           { type: Boolean, default: false },
  readBy:           [{ type: mongoose.Schema.Types.ObjectId, ref: 'User' }],
}, { timestamps: true });

module.exports = mongoose.model('Notification', notificationSchema);
