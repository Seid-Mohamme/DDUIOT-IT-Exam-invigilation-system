/* Date/time normalization and clash detection utilities */

const pad2 = (n) => String(n).padStart(2, '0');

// "2026-11-16" | "16/11/2026" | "16-11-2026" | Date object -> "YYYY-MM-DD"
function normDate(v) {
  if (v === undefined || v === null || v === '') return null;
  if (v instanceof Date && !isNaN(v)) {
    return `${v.getFullYear()}-${pad2(v.getMonth() + 1)}-${pad2(v.getDate())}`;
  }
  const s = String(v).trim();
  let m = s.match(/^(\d{4})-(\d{1,2})-(\d{1,2})/);
  if (m) return `${m[1]}-${pad2(+m[2])}-${pad2(+m[3])}`;
  m = s.match(/^(\d{1,2})[\/\-.](\d{1,2})[\/\-.](\d{4})$/); // DD/MM/YYYY
  if (m) return `${m[3]}-${pad2(+m[2])}-${pad2(+m[1])}`;
  const d = new Date(s);
  if (!isNaN(d)) return `${d.getFullYear()}-${pad2(d.getMonth() + 1)}-${pad2(d.getDate())}`;
  return null;
}

// "8:00 AM" | "14:00" | "8" | "8.5" | Excel time cell -> "HH:MM" (24h)
function normTime(v) {
  if (v === undefined || v === null || v === '') return null;
  if (v instanceof Date && !isNaN(v)) return `${pad2(v.getHours())}:${pad2(v.getMinutes())}`;
  const s = String(v).trim().toUpperCase().replace(/\s+/g, ' ');
  let m = s.match(/^(\d{1,2})[:.](\d{2})\s*(AM|PM)?$/);
  if (!m) m = s.match(/^(\d{1,2})\s*(AM|PM)$/);
  if (!m) {
    const num = Number(s);
    if (!isNaN(num) && num > 0 && num <= 24) {
      return `${pad2(Math.floor(num))}:${pad2(Math.round((num % 1) * 60) % 60)}`;
    }
    return null;
  }
  let h = parseInt(m[1], 10);
  const min = /^\d{2}$/.test(m[2] || '') ? parseInt(m[2], 10) : 0;
  const ap = m[3] || (/^(AM|PM)$/.test(m[2] || '') ? m[2] : '');
  if (ap === 'PM' && h < 12) h += 12;
  if (ap === 'AM' && h === 12) h = 0;
  if (h > 23 || min > 59) return null;
  return `${pad2(h)}:${pad2(min)}`;
}

const toMin = (t) => { const [h, mm] = String(t).split(':').map(Number); return h * 60 + mm; };

// do two exam slots overlap on the same date?
const clash = (d1, s1, e1, d2, s2, e2) =>
  d1 === d2 && toMin(s1) < toMin(e2) && toMin(s2) < toMin(e1);

module.exports = { pad2, normDate, normTime, toMin, clash };
