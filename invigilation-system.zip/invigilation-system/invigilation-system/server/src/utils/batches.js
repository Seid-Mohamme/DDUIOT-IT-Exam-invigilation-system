/* Canonical student batches of the IT department */
const BATCHES = [
  '2nd Year 1st Semester',
  '3rd Year 1st Semester',
  '4th Year 1st Semester',
  '4th Year 2nd Semester',
];

/* Map any spelling found in an uploaded sheet to a canonical batch,
   e.g. "it 4th year 2nd sem." -> "4th Year 2nd Semester". Returns '' if unknown. */
function normBatch(v) {
  const s = String(v || '').toLowerCase().replace(/[^a-z0-9]/g, '');
  if (!s) return '';
  if (/2ndyear.*1st|1styear.*2nd|y2.*s1|2y1s/.test(s)) return BATCHES[0];
  if (/3rdyear.*1st|y3.*s1|3y1s/.test(s)) return BATCHES[1];
  if (/4thyear.*1st|y4.*s1|4y1s/.test(s)) return BATCHES[2];
  if (/4thyear.*2nd|y4.*s2|4y2s/.test(s)) return BATCHES[3];
  const exact = BATCHES.find((b) => b.toLowerCase().replace(/[^a-z0-9]/g, '') === s);
  return exact || '';
}

module.exports = { BATCHES, normBatch };
