/* Automatically create a login account for every invigilator added to the
   system (single add or Excel/CSV upload).

   - one login per invigilator record (linked by the `invigilator` field)
   - email: the invigilator's email if given, otherwise generated from the
     Staff ID, e.g. DDU/STF/2101 -> ddu.stf.2101@ddu.edu.et
   - default password: invig@123  (the admin can reset it in User Accounts) */
const User = require('../models/User');

const DEFAULT_PASSWORD = 'invig@123';

const staffEmail = (staffId) => {
  const parts = String(staffId || '').toLowerCase().split(/[^a-z0-9]+/).filter(Boolean);
  return parts.length ? parts.join('.') + '@ddu.edu.et' : '';
};

async function createLogin(inv, emailOverride) {
  const passwordHash = await require('bcryptjs').hash(DEFAULT_PASSWORD, 10);
  const user = await User.create({
    name: inv.name,
    email: emailOverride,
    passwordHash,
    role: 'invigilator',
    invigilator: inv._id,
  });
  return user;
}

/* returns { created: Boolean, user?, email?, reason? } */
async function ensureInvigilatorLogin(inv) {
  const existing = await User.findOne({ invigilator: inv._id }).lean();
  if (existing) return { created: false, reason: 'already has a login', email: existing.email };

  const candidates = [];
  if (inv.email && String(inv.email).trim()) candidates.push(String(inv.email).trim().toLowerCase());
  const fromStaff = staffEmail(inv.staffId);
  if (fromStaff) candidates.push(fromStaff);
  if (!candidates.length) candidates.push('invigilator.' + String(inv._id).slice(-6) + '@ddu.edu.et');

  for (const email of candidates) {
    try {
      const user = await createLogin(inv, email);
      return { created: true, user, email };
    } catch (e) {
      if (e.code !== 11000) return { created: false, reason: e.message };
      /* email taken - try the next candidate (final candidate: add a suffix) */
    }
  }
  /* all candidate emails taken - last resort: unique suffixed email */
  try {
    const email = candidates[candidates.length - 1].replace('@', '.' + String(inv._id).slice(-4) + '@');
    const user = await createLogin(inv, email);
    return { created: true, user, email };
  } catch (e) {
    return { created: false, reason: e.message };
  }
}

module.exports = { ensureInvigilatorLogin, DEFAULT_PASSWORD };
