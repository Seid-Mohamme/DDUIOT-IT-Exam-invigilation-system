/* Missed invigilation (absence) workflow:
   1. Exam Coordinator records "missed invigilation" on an assignment
      -> URGENT notification to Department Head + coordinator(s): REPLACE!
      -> best-effort Telegram push to the department group
   2. The invigilator submits WHY they missed it (excuse)
      -> notification to staff
   3. The Department Head takes the measure and closes the record
      -> notification to that invigilator                                */
const MissedInvigilation = require('../models/MissedInvigilation');
const Assignment = require('../models/Assignment');
const Notification = require('../models/Notification');
const { tgPush } = require('./telegramController');

const fail = (status, message) => { const e = new Error(message); e.status = status; return e; };
const examLine = (exam) =>
  `${exam.courseCode} on ${exam.date}, ${exam.startTime}-${exam.endTime}${exam.venue ? ' at ' + exam.venue : ''}`;

/* POST /api/missed  { assignmentId, note }  - staff (coordinator / admin) */
exports.record = async (req, res, next) => {
  try {
    const { assignmentId, note } = req.body;
    const a = await Assignment.findById(assignmentId).populate(['exam', 'invigilator']);
    if (!a || !a.exam || !a.invigilator) throw fail(404, 'Assignment not found');

    const dup = await MissedInvigilation.findOne({ assignment: a._id });
    if (dup) throw fail(400, 'This absence is already recorded - open "Absences & Feedback" to manage it');

    const rec = await MissedInvigilation.create({
      assignment: a._id, exam: a.exam._id, invigilator: a.invigilator._id,
      note: String(note || '').trim(), reportedBy: req.user.id, status: 'Open',
    });

    const title = `ABSENCE: ${a.invigilator.name} missed ${a.exam.courseCode}`;
    const body = `${a.invigilator.name} did NOT show up for ${examLine(a.exam)}. ` +
      'Please REPLACE with another invigilator as soon as possible (use "Suggest" on the Assignments page).';
    await Notification.create({
      audience: 'staff', type: 'absence', title, body,
      examId: a.exam._id, assignmentId: a._id, urgent: true,
    });
    tgPush(`⚠️ ${title}\n${body}\nRecorded by: ${req.user.name || 'Exam coordinator'}${note ? '\nNote: ' + note : ''}`);

    res.status(201).json(await rec.populate(['exam', 'invigilator', 'reportedBy']));
  } catch (e) { next(e); }
};

/* GET /api/missed - staff: all records */
exports.list = async (req, res, next) => {
  try {
    const rows = await MissedInvigilation.find({})
      .populate({ path: 'exam', select: 'courseCode courseTitle date startTime endTime venue batch' })
      .populate('invigilator')
      .populate('reportedBy', 'name role')
      .populate('actionBy', 'name')
      .sort({ createdAt: -1 }).lean();
    res.json(rows.filter((r) => r.exam && r.invigilator));
  } catch (e) { next(e); }
};

/* GET /api/missed/mine - invigilator: own records */
exports.mine = async (req, res, next) => {
  try {
    if (!req.user.invigilatorId) return res.json([]);
    const rows = await MissedInvigilation.find({ invigilator: req.user.invigilatorId })
      .populate({ path: 'exam', select: 'courseCode courseTitle date startTime endTime venue' })
      .populate('invigilator')
      .sort({ createdAt: -1 }).lean();
    res.json(rows.filter((r) => r.exam));
  } catch (e) { next(e); }
};

/* POST /api/missed/:id/excuse  { text }  - the invigilator explains WHY */
exports.excuse = async (req, res, next) => {
  try {
    const rec = await MissedInvigilation.findById(req.params.id).populate(['exam', 'invigilator']);
    if (!rec) throw fail(404, 'Absence record not found');
    if (String(req.user.invigilatorId || '') !== String(rec.invigilator._id)) {
      throw fail(403, 'Only the invigilator of this exam can submit the reason');
    }
    const text = String(req.body.text || '').trim();
    if (!text) throw fail(400, 'Please write the reason why you missed the invigilation');
    rec.excuseText = text;
    rec.excuseAt = new Date();
    if (rec.status === 'Open') rec.status = 'Explained';
    await rec.save();

    await Notification.create({
      audience: 'staff', type: 'excuse',
      title: `Reason submitted: ${rec.invigilator.name} - ${rec.exam.courseCode}`,
      body: `"${text.slice(0, 300)}" - submitted for the absence of ${examLine(rec.exam)}. ` +
        'The Department Head can now take the measure in "Absences & Feedback".',
      examId: rec.exam._id,
    });

    res.json(await rec.populate(['exam', 'invigilator']));
  } catch (e) { next(e); }
};

/* PUT /api/missed/:id/action  { actionTaken }  - Department Head takes the measure */
exports.takeAction = async (req, res, next) => {
  try {
    if (req.user.role !== 'admin') throw fail(403, 'Only the Department Head can take the measure');
    const rec = await MissedInvigilation.findById(req.params.id).populate(['exam', 'invigilator']);
    if (!rec) throw fail(404, 'Absence record not found');
    const actionTaken = String(req.body.actionTaken || '').trim();
    if (!actionTaken) throw fail(400, 'Describe the measure taken');

    rec.actionTaken = actionTaken;
    rec.actionAt = new Date();
    rec.actionBy = req.user.id;
    rec.status = 'Closed';
    await rec.save();

    await Notification.create({
      audience: 'invigilator', targetInvigilator: rec.invigilator._id, type: 'measure',
      title: `Measure taken on your missed invigilation - ${rec.exam.courseCode}`,
      body: `The Department Head recorded: "${actionTaken.slice(0, 300)}"`,
      examId: rec.exam._id,
    });

    res.json(await rec.populate(['exam', 'invigilator', 'actionBy']));
  } catch (e) { next(e); }
};

/* DELETE /api/missed/:id - admin removes a wrong record */
exports.remove = async (req, res, next) => {
  try {
    if (req.user.role !== 'admin') throw fail(403, 'Only the Department Head can delete absence records');
    await MissedInvigilation.findByIdAndDelete(req.params.id);
    res.json({ ok: true });
  } catch (e) { next(e); }
};
