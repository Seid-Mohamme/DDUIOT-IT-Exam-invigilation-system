/* Feedback from invigilators to the department */
const Feedback = require('../models/Feedback');
const Notification = require('../models/Notification');
const Assignment = require('../models/Assignment');

const fail = (status, message) => { const e = new Error(message); e.status = status; return e; };

/* POST /api/feedback  { examId?, assignmentId?, category, message } - invigilator */
exports.submit = async (req, res, next) => {
  try {
    if (!req.user.invigilatorId) throw fail(403, 'Only invigilators can send feedback');
    const message = String(req.body.message || '').trim();
    if (!message) throw fail(400, 'Please write your feedback');
    const category = ['General', 'Issue', 'Suggestion', 'Other'].includes(req.body.category)
      ? req.body.category : 'General';

    let exam = null;
    if (req.body.assignmentId) {
      const a = await Assignment.findById(req.body.assignmentId).populate('exam');
      if (a && String(a.invigilator) === String(req.user.invigilatorId)) {
        exam = a.exam ? a.exam._id : null;
      }
    }

    const fb = await Feedback.create({
      invigilator: req.user.invigilatorId, exam, assignment: req.body.assignmentId || null,
      category, message,
    });

    await Notification.create({
      audience: 'staff', type: 'feedback',
      title: `New feedback from ${req.user.name || 'an invigilator'} (${category})`,
      body: message.slice(0, 300),
    });

    res.status(201).json(await fb.populate(['invigilator', 'exam']));
  } catch (e) { next(e); }
};

/* GET /api/feedback - staff: all feedback */
exports.list = async (req, res, next) => {
  try {
    const rows = await Feedback.find({})
      .populate('invigilator')
      .populate({ path: 'exam', select: 'courseCode courseTitle date' })
      .sort({ createdAt: -1 }).lean();
    res.json(rows.filter((r) => r.invigilator));
  } catch (e) { next(e); }
};

/* GET /api/feedback/mine - invigilator: own feedback */
exports.mine = async (req, res, next) => {
  try {
    if (!req.user.invigilatorId) return res.json([]);
    const rows = await Feedback.find({ invigilator: req.user.invigilatorId })
      .populate({ path: 'exam', select: 'courseCode courseTitle date' })
      .sort({ createdAt: -1 }).lean();
    res.json(rows);
  } catch (e) { next(e); }
};
