/* In-app notification center.
   Stored notifications (absence alerts, check-ins, confirmations, feedback,
   measures) + computed "to-do" reminders. Today's exam reminders for
   invigilators are also computed here from their assignments. */
const Notification = require('../models/Notification');
const MissedInvigilation = require('../models/MissedInvigilation');
const Assignment = require('../models/Assignment');

const isStaffRole = (r) => r === 'admin' || r === 'coordinator';

/* GET /api/notifications  -> { items: [...], unread: n } */
exports.list = async (req, res, next) => {
  try {
    const uid = String(req.user.id);
    const staff = isStaffRole(req.user.role);

    const filter = staff
      ? { audience: 'staff' }
      : { audience: 'invigilator',
          $or: [{ targetInvigilator: null },
                { targetInvigilator: req.user.invigilatorId || null }] };

    const rows = (await Notification.find(filter).sort({ createdAt: -1 }).limit(50).lean())
      .filter((n) => !n.readBy.some((r) => String(r) === uid));

    const items = rows.map((n) => ({
      id: n._id, type: n.type, title: n.title, body: n.body,
      urgent: n.urgent, at: n.createdAt, examId: n.examId, assignmentId: n.assignmentId,
    }));

    /* --- computed reminders for invigilators --- */
    if (!staff && req.user.invigilatorId) {
      /* pending: explain WHY you missed an invigilation */
      const pending = await MissedInvigilation.find({
        invigilator: req.user.invigilatorId, excuseText: '',
      }).populate('exam', 'courseCode courseTitle date startTime').lean();
      pending.forEach((m) => {
        if (!m.exam) return;
        items.push({
          id: 'todo-' + m._id, type: 'todo', persistent: false,
          title: `Explain your missed invigilation - ${m.exam.courseCode}`,
          body: `The coordinator recorded that you missed ${m.exam.courseCode} on ${m.exam.date} ` +
            `${m.exam.startTime}. Open "My Exams" and submit your reason.`,
          urgent: true, at: m.createdAt,
        });
      });
    }

    /* --- computed reminder for staff: open absences still not closed --- */
    if (staff) {
      const open = await MissedInvigilation.countDocuments({ status: { $ne: 'Closed' } });
      if (open > 0) {
        items.push({
          id: 'todo-open-absences', type: 'todo',
          title: `${open} absence record(s) waiting for your measure`,
          body: 'Open "Absences & Feedback" to review the reasons and take the measure.',
          urgent: open > 0, at: new Date(),
        });
      }
    }

    res.json({ items, unread: items.length });
  } catch (e) { next(e); }
};

/* POST /api/notifications/read  { ids: [...] } - mark stored ones as read */
exports.markRead = async (req, res, next) => {
  try {
    const ids = (Array.isArray(req.body.ids) ? req.body.ids : []).filter(Boolean);
    if (!ids.length) return res.json({ ok: true, marked: 0 });
    const r = await Notification.updateMany(
      { _id: { $in: ids.filter((x) => String(x).length === 24) } },
      { $addToSet: { readBy: req.user.id } });
    res.json({ ok: true, marked: r.modifiedCount || 0 });
  } catch (e) { next(e); }
};
