const Invigilator = require('../models/Invigilator');
const Assignment = require('../models/Assignment');
const { ensureInvigilatorLogin, DEFAULT_PASSWORD } = require('../utils/autoLogin');

exports.list = async (req, res, next) => {
  try {
    res.json(await Invigilator.find({}).sort({ name: 1 }).lean());
  } catch (e) { next(e); }
};

/* POST /api/invigilators - add one invigilator.
   A LOGIN ACCOUNT IS CREATED AUTOMATICALLY (default password: invig@123). */
exports.create = async (req, res, next) => {
  try {
    const inv = await Invigilator.create(req.body);
    const login = await ensureInvigilatorLogin(inv);
    res.status(201).json({
      ...inv.toObject(),
      loginCreated: login.created,
      loginEmail: login.email,
      loginReason: login.reason,
      defaultPassword: login.created ? DEFAULT_PASSWORD : undefined,
    });
  } catch (e) { next(e); }
};

exports.update = async (req, res, next) => {
  try {
    res.json(await Invigilator.findByIdAndUpdate(req.params.id, req.body,
      { new: true, runValidators: true }));
  } catch (e) { next(e); }
};

exports.remove = async (req, res, next) => {
  try {
    await Assignment.deleteMany({ invigilator: req.params.id });
    await Invigilator.findByIdAndDelete(req.params.id);
    res.json({ ok: true });
  } catch (e) { next(e); }
};

exports.removeAll = async (req, res, next) => {
  try {
    await Assignment.deleteMany({});
    await Invigilator.deleteMany({});
    res.json({ ok: true });
  } catch (e) { next(e); }
};

/* Bulk import (rows already column-mapped by the frontend).
   Every imported invigilator gets a login account automatically. */
exports.importInvigilators = async (req, res, next) => {
  try {
    const rows = Array.isArray(req.body) ? req.body : req.body.rows || [];
    const errors = [];
    let imported = 0;
    let loginsCreated = 0;
    for (let i = 0; i < rows.length; i++) {
      const r = rows[i];
      const name = String(r.name || '').trim();
      if (!name) { errors.push(`Row ${i + 1}: missing name`); continue; }
      const staffId = String(r.staffId || '').trim() || `INV-${Date.now()}-${i}`;
      try {
        const inv = await Invigilator.create({
          name,
          staffId,
          department: String(r.department || '').trim(),
          email: String(r.email || '').trim(),
          phone: String(r.phone || '').trim(),
          maxLoad: Math.max(1, Number(r.maxLoad) || 4),
        });
        imported++;
        const login = await ensureInvigilatorLogin(inv);
        if (login.created) loginsCreated++;
      } catch (e) {
        errors.push(`Row ${i + 1}: ${e.code === 11000 ? `duplicate Staff ID "${staffId}"` : e.message}`);
      }
    }
    res.json({ imported, loginsCreated, errors, defaultPassword: DEFAULT_PASSWORD });
  } catch (e) { next(e); }
};
