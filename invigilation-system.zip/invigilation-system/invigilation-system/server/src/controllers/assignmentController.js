const Assignment = require('../models/Assignment');
const Notification = require('../models/Notification');
const { assignInvigilator, autoAssign, updateAssignment } = require('../services/assignmentService');

const fail = (status, message) => { const e = new Error(message); e.status = status; return e; };

exports.list = async (req, res, next) => {
  try {
    const rows = await Assignment.find({})
      .populate('exam').populate('invigilator').lean();
    res.json(rows.filter((r) => r.exam && r.invigilator));
  } catch (e) { next(e); }
};

/* GET /api/assignments/mine - the logged-in invigilator's own exams */
exports.mine = async (req, res, next) => {
  try {
    if (!req.user.invigilatorId) return res.json([]);
    const rows = await Assignment.find({ invigilator: req.user.invigilatorId })
      .populate('exam').populate('invigilator').lean();
    res.json(rows.filter((r) => r.exam && r.invigilator));
  } catch (e) { next(e); }
};

exports.create = async (req, res, next) => {
  try {
    const created = await assignInvigilator(req.body.examId, req.body.invigilatorId);
    await created.populate(['exam', 'invigilator']);
    res.status(201).json(created);
  } catch (e) { next(e); }
};

exports.auto = async (req, res, next) => {
  try { res.json(await autoAssign()); } catch (e) { next(e); }
};

/* PUT /api/assignments/:id - Department Head fixes a wrong assignment
   (change the invigilator and/or the role) */
exports.update = async (req, res, next) => {
  try {
    const updated = await updateAssignment(req.params.id, {
      invigilatorId: req.body.invigilatorId,
      role: req.body.role,
    });
    res.json(updated);
  } catch (e) { next(e); }
};

exports.setStatus = async (req, res, next) => {
  try {
    const allowed = ['Assigned', 'Accepted', 'Declined'];
    if (!allowed.includes(req.body.status)) {
      return res.status(400).json({ message: 'Status must be Assigned, Accepted or Declined' });
    }
    const a = await Assignment.findByIdAndUpdate(req.params.id,
      { status: req.body.status }, { new: true }).populate(['exam', 'invigilator']);
    if (!a) return res.status(404).json({ message: 'Assignment not found' });
    res.json(a);
  } catch (e) { next(e); }
};

exports.remove = async (req, res, next) => {
  try {
    await Assignment.findByIdAndDelete(req.params.id);
    res.json({ ok: true });
  } catch (e) { next(e); }
};

exports.removeAll = async (req, res, next) => {
  try {
    await Assignment.deleteMany({});
    res.json({ ok: true });
  } catch (e) { next(e); }
};

/* PATCH /api/assignments/:id/checkin - the invigilator confirms
   "I am in the exam room" -> the department sees it immediately */
exports.checkIn = async (req, res, next) => {
  try {
    const a = await Assignment.findById(req.params.id).populate(['exam', 'invigilator']);
    if (!a || !a.exam || !a.invigilator) throw fail(404, 'Assignment not found');
    if (String(req.user.invigilatorId || '') !== String(a.invigilator._id)) {
      throw fail(403, 'Only the assigned invigilator can check in');
    }
    a.checkInAt = new Date();
    await a.save();
    await Notification.create({
      audience: 'staff', type: 'checkin',
      title: `${a.invigilator.name} is in the exam room - ${a.exam.courseCode}`,
      body: `"I am in the exam room." Check-in for ${a.exam.courseCode} (${a.exam.date}, ` +
        `${a.exam.startTime}-${a.exam.endTime}${a.exam.venue ? ', ' + a.exam.venue : ''}).`,
      examId: a.exam._id, assignmentId: a._id,
    });
    res.json(a);
  } catch (e) { next(e); }
};

/* PATCH /api/assignments/:id/confirm-safe - "the exam is running safely" */
exports.confirmSafe = async (req, res, next) => {
  try {
    const a = await Assignment.findById(req.params.id).populate(['exam', 'invigilator']);
    if (!a || !a.exam || !a.invigilator) throw fail(404, 'Assignment not found');
    if (String(req.user.invigilatorId || '') !== String(a.invigilator._id)) {
      throw fail(403, 'Only the assigned invigilator can confirm this');
    }
    a.runningConfirmedAt = new Date();
    await a.save();
    await Notification.create({
      audience: 'staff', type: 'safe',
      title: `${a.exam.courseCode} is running safely - confirmed by ${a.invigilator.name}`,
      body: `"The exam is continuing safely." ${a.exam.courseCode} (${a.exam.date}, ` +
        `${a.exam.startTime}-${a.exam.endTime}${a.exam.venue ? ', ' + a.exam.venue : ''}).`,
      examId: a.exam._id, assignmentId: a._id,
    });
    res.json(a);
  } catch (e) { next(e); }
};
