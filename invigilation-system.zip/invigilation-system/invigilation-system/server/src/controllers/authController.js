/* Login / user accounts management */
const bcrypt = require('bcryptjs');
const User = require('../models/User');
const Invigilator = require('../models/Invigilator');
const { signToken } = require('../middleware/auth');

const publicUser = (u) => ({
  id: u._id, name: u.name, email: u.email, role: u.role, active: u.active,
  invigilatorId: u.invigilator && u.invigilator._id ? u.invigilator._id : u.invigilator,
  invigilatorName: u.invigilator && u.invigilator.name ? u.invigilator.name : undefined,
});

/* POST /api/auth/login */
exports.login = async (req, res, next) => {
  try {
    const email = String(req.body.email || '').trim().toLowerCase();
    const password = String(req.body.password || '');
    if (!email || !password) return res.status(400).json({ message: 'Email and password are required' });

    const user = await User.findOne({ email }).populate('invigilator');
    if (!user || !user.active) return res.status(401).json({ message: 'Invalid email or password' });

    const ok = await bcrypt.compare(password, user.passwordHash);
    if (!ok) return res.status(401).json({ message: 'Invalid email or password' });

    res.json({ token: signToken(user), user: publicUser(user) });
  } catch (e) { next(e); }
};

/* GET /api/auth/me - restore session on page reload */
exports.me = async (req, res, next) => {
  try {
    const user = await User.findById(req.user.id).populate('invigilator');
    if (!user || !user.active) return res.status(401).json({ message: 'Account disabled' });
    res.json(publicUser(user));
  } catch (e) { next(e); }
};

/* GET /api/auth/users - admin: list all accounts */
exports.listUsers = async (req, res, next) => {
  try {
    const users = await User.find({}).populate('invigilator', 'name staffId').lean();
    res.json(users.map((u) => ({
      id: u._id, name: u.name, email: u.email, role: u.role, active: u.active,
      invigilatorId: u.invigilator && u.invigilator._id,
      invigilatorName: u.invigilator && u.invigilator.name,
      createdAt: u.createdAt,
    })));
  } catch (e) { next(e); }
};

/* POST /api/auth/users - admin: create an account
   Roles: 'admin' (Department Head), 'coordinator' (Exam Coordinator), 'invigilator'.
   An invigilator login must be linked to one invigilator record. */
exports.createUser = async (req, res, next) => {
  try {
    const { name, email, password, role, invigilatorId } = req.body;
    if (!email || !password) return res.status(400).json({ message: 'Email and password are required' });
    if (String(password).length < 4) return res.status(400).json({ message: 'Password must be at least 4 characters' });
    const r = ['admin', 'coordinator', 'invigilator'].includes(role) ? role : 'invigilator';

    let finalName = String(name || '').trim();
    if (r === 'invigilator') {
      if (!invigilatorId) return res.status(400).json({ message: 'Select which invigilator this login belongs to' });
      const inv = await Invigilator.findById(invigilatorId);
      if (!inv) return res.status(404).json({ message: 'Invigilator not found' });
      if (!finalName) finalName = inv.name;
    }
    if (!finalName) return res.status(400).json({ message: 'Name is required' });

    const passwordHash = await bcrypt.hash(String(password), 10);
    const user = await User.create({ name: finalName, email, passwordHash, role: r,
      invigilator: r === 'invigilator' ? invigilatorId : null });
    res.status(201).json(publicUser(user));
  } catch (e) {
    if (e.code === 11000) return res.status(400).json({ message: 'An account with this email already exists' });
    next(e);
  }
};

/* PUT /api/auth/users/:id - admin: edit an account (rename, change email/role,
   re-link the invigilator, enable or disable the login).
   Safety: you cannot change your own role or disable your own account. */
exports.updateUser = async (req, res, next) => {
  try {
    const user = await User.findById(req.params.id);
    if (!user) return res.status(404).json({ message: 'User not found' });

    const isSelf = String(user._id) === String(req.user.id);
    const { name, email, role, invigilatorId, active } = req.body;

    if (name !== undefined) {
      const n = String(name).trim();
      if (!n) return res.status(400).json({ message: 'Name cannot be empty' });
      user.name = n;
    }
    if (email !== undefined && String(email).trim()) user.email = String(email).trim().toLowerCase();

    if (role !== undefined) {
      if (isSelf && role !== user.role) {
        return res.status(400).json({ message: 'You cannot change the role of the account you are logged in with' });
      }
      if (!['admin', 'coordinator', 'invigilator'].includes(role)) {
        return res.status(400).json({ message: 'Role must be admin, coordinator or invigilator' });
      }
      user.role = role;
    }

    if (invigilatorId !== undefined) {
      if (user.role === 'invigilator') {
        if (!invigilatorId) return res.status(400).json({ message: 'An invigilator login must be linked to an invigilator' });
        const inv = await Invigilator.findById(invigilatorId);
        if (!inv) return res.status(404).json({ message: 'Invigilator not found' });
        user.invigilator = inv._id;
        if (name === undefined && !user.name) user.name = inv.name;
      } else {
        user.invigilator = null;
      }
    }

    if (active !== undefined) {
      if (isSelf && !active) {
        return res.status(400).json({ message: 'You cannot disable the account you are logged in with' });
      }
      user.active = !!active;
    }

    await user.save();
    const populated = await User.findById(user._id).populate('invigilator');
    res.json(publicUser(populated));
  } catch (e) {
    if (e.code === 11000) return res.status(400).json({ message: 'An account with this email already exists' });
    next(e);
  }
};

/* PUT /api/auth/users/:id/password - admin: reset a password */
exports.resetPassword = async (req, res, next) => {
  try {
    const password = String(req.body.password || '');
    if (password.length < 4) return res.status(400).json({ message: 'Password must be at least 4 characters' });
    const user = await User.findById(req.params.id);
    if (!user) return res.status(404).json({ message: 'User not found' });
    user.passwordHash = await bcrypt.hash(password, 10);
    await user.save();
    res.json({ ok: true });
  } catch (e) { next(e); }
};

/* DELETE /api/auth/users/:id - admin: remove an account */
exports.removeUser = async (req, res, next) => {
  try {
    if (String(req.params.id) === String(req.user.id)) {
      return res.status(400).json({ message: 'You cannot delete your own account while logged in' });
    }
    const user = await User.findById(req.params.id);
    if (!user) return res.status(404).json({ message: 'User not found' });
    if (user.role === 'admin') {
      const admins = await User.countDocuments({ role: 'admin', active: true, _id: { $ne: user._id } });
      if (admins === 0) return res.status(400).json({ message: 'Cannot delete the last active admin account' });
    }
    await User.findByIdAndDelete(req.params.id);
    res.json({ ok: true });
  } catch (e) { next(e); }
};
