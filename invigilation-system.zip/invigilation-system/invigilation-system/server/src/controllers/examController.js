const Exam = require('../models/Exam');
const Assignment = require('../models/Assignment');
const { normDate, normTime } = require('../utils/timeUtils');
const { normBatch } = require('../utils/batches');

exports.list = async (req, res, next) => {
  try {
    res.json(await Exam.find({}).sort({ date: 1, startTime: 1, courseCode: 1 }).lean());
  } catch (e) { next(e); }
};

exports.create = async (req, res, next) => {
  try { res.status(201).json(await Exam.create(req.body)); } catch (e) { next(e); }
};

exports.update = async (req, res, next) => {
  try {
    res.json(await Exam.findByIdAndUpdate(req.params.id, req.body,
      { new: true, runValidators: true }));
  } catch (e) { next(e); }
};

exports.remove = async (req, res, next) => {
  try {
    await Assignment.deleteMany({ exam: req.params.id });
    await Exam.findByIdAndDelete(req.params.id);
    res.json({ ok: true });
  } catch (e) { next(e); }
};

exports.removeAll = async (req, res, next) => {
  try {
    await Assignment.deleteMany({});
    await Exam.deleteMany({});
    res.json({ ok: true });
  } catch (e) { next(e); }
};

/* Bulk import (rows already column-mapped by the frontend) */
exports.importExams = async (req, res, next) => {
  try {
    const rows = Array.isArray(req.body) ? req.body : req.body.rows || [];
    const docs = [];
    const errors = [];
    rows.forEach((r, i) => {
      const code = String(r.courseCode || '').trim();
      const date = normDate(r.date);
      const start = normTime(r.startTime);
      const end = normTime(r.endTime);
      if (!code || !date || !start || !end) {
        errors.push(`Row ${i + 1}: needs course code, date, start time and end time`);
        return;
      }
      docs.push({
        courseCode: code.toUpperCase(),
        courseTitle: String(r.courseTitle || '').trim(),
        section: String(r.section || '').trim(),
        batch: normBatch(r.batch),
        examType: /mid/i.test(String(r.examType)) ? 'Mid' : 'Final',
        date, startTime: start, endTime: end,
        venue: String(r.venue || '').trim(),
        studentsCount: Number(r.studentsCount) || 0,
        requiredInvigilators: Math.max(1, Number(r.requiredInvigilators) || 1),
      });
    });
    if (docs.length) await Exam.insertMany(docs);
    res.json({ imported: docs.length, errors });
  } catch (e) { next(e); }
};
