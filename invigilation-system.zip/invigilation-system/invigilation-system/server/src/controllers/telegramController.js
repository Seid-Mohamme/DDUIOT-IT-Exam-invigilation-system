/* Telegram sharing - Department Head can send the assignment report
   (text summary or the Excel file) to a Telegram group / chat.

   Setup (one time): create a bot with @BotFather, copy the bot token,
   add the bot to the department group (or chat with it), get the chat id,
   then save both in Reports -> Telegram Settings.                        */
const Setting = require('../models/Setting');

const fail = (status, message) => { const e = new Error(message); e.status = status; return e; };

async function getSetting() {
  const s = await Setting.findOne({ key: 'telegram' }).lean();
  return s || { botToken: '', chatId: '' };
}

async function tgCall(token, method, body) {
  let res;
  try {
    res = await fetch(`https://api.telegram.org/bot${token}/${method}`, {
      method: 'POST',
      headers: body instanceof FormData ? undefined : { 'Content-Type': 'application/json' },
      body: body instanceof FormData ? body : JSON.stringify(body),
    });
  } catch {
    throw fail(502, 'Could not reach api.telegram.org - check the internet connection');
  }
  const data = await res.json().catch(() => ({}));
  if (!data.ok) {
    throw fail(400, `Telegram error: ${data.description || res.status}` +
      (String(data.description || '').includes('chat not found')
        ? ' - check the chat id (add the bot to the group / send it a message first)' : '') +
      (String(data.description || '').includes('Unauthorized')
        ? ' - the bot token is wrong (get it from @BotFather)' : ''));
  }
  return data.result;
}

/* GET /api/telegram/settings */
exports.getSettings = async (req, res, next) => {
  try {
    const s = await getSetting();
    const configured = Boolean(s.botToken && s.chatId);
    res.json({
      configured,
      chatId: s.chatId || '',
      botTokenMasked: s.botToken ? s.botToken.slice(0, 8) + '...' : '',
    });
  } catch (e) { next(e); }
};

/* PUT /api/telegram/settings */
exports.saveSettings = async (req, res, next) => {
  try {
    const botToken = String(req.body.botToken || '').trim();
    const chatId = String(req.body.chatId || '').trim();
    await Setting.updateOne({ key: 'telegram' }, { botToken, chatId }, { upsert: true });
    res.json({ ok: true, configured: Boolean(botToken && chatId) });
  } catch (e) { next(e); }
};

/* POST /api/telegram/test */
exports.test = async (req, res, next) => {
  try {
    const s = await getSetting();
    if (!s.botToken || !s.chatId) throw fail(400, 'Save the bot token and chat id first');
    await tgCall(s.botToken, 'sendMessage', {
      chat_id: s.chatId,
      text: '✅ Test message from DDU-IT Invigilation System.\nThe connection works - you can now share assignment reports here.',
    });
    res.json({ ok: true });
  } catch (e) { next(e); }
};

/* Internal one-way push used by other features (e.g. absence alerts).
   Silent no-op when the bot is not configured or Telegram fails. */
exports.tgPush = async (text) => {
  try {
    const s = await getSetting();
    if (!s.botToken || !s.chatId) return false;
    await tgCall(s.botToken, 'sendMessage', { chat_id: s.chatId, text: String(text).slice(0, 4000) });
    return true;
  } catch { return false; }
};

/* POST /api/telegram/send-text  { text } */
exports.sendText = async (req, res, next) => {
  try {
    const text = String(req.body.text || '').trim();
    if (!text) throw fail(400, 'Nothing to send');
    const s = await getSetting();
    if (!s.botToken || !s.chatId) throw fail(400, 'Configure Telegram first (Reports -> Telegram Settings)');
    await tgCall(s.botToken, 'sendMessage', { chat_id: s.chatId, text: text.slice(0, 4000) });
    res.json({ ok: true });
  } catch (e) { next(e); }
};

/* POST /api/telegram/send-file  { filename, base64, caption } */
exports.sendFile = async (req, res, next) => {
  try {
    const { filename, base64, caption } = req.body;
    if (!base64) throw fail(400, 'No file received');
    const s = await getSetting();
    if (!s.botToken || !s.chatId) throw fail(400, 'Configure Telegram first (Reports -> Telegram Settings)');

    const buf = Buffer.from(String(base64).replace(/^data:[^;]+;base64,/, ''), 'base64');
    if (buf.length > 50 * 1024 * 1024) throw fail(400, 'File is larger than the Telegram 50 MB limit');

    const fd = new FormData();
    fd.append('chat_id', s.chatId);
    if (caption) fd.append('caption', String(caption).slice(0, 1000));
    fd.append('document', new Blob([buf]), String(filename || 'report.xlsx'));
    await tgCall(s.botToken, 'sendDocument', fd);
    res.json({ ok: true });
  } catch (e) { next(e); }
};
