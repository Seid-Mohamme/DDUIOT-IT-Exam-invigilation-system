const Exam = require('../models/Exam');
const Invigilator = require('../models/Invigilator');
const Assignment = require('../models/Assignment');

/* GET /api/stats/summary */
exports.summary = async (req, res, next) => {
  try {
    const examDocs = await Exam.find({}).lean();
    const [invigilators, assignments, counts] = await Promise.all([
      Invigilator.countDocuments({}),
      Assignment.countDocuments({}),
      Assignment.aggregate([{ $group: { _id: '$exam', n: { $sum: 1 } } }]),
    ]);
    const map = new Map(counts.map((c) => [String(c._id), c.n]));
    const required = examDocs.reduce((s, e) => s + (e.requiredInvigilators || 1), 0);
    const filled = examDocs.reduce((s, e) =>
      s + Math.min(map.get(String(e._id)) || 0, e.requiredInvigilators || 1), 0);
    const fullyAssigned = examDocs.filter((e) =>
      (map.get(String(e._id)) || 0) >= (e.requiredInvigilators || 1)).length;

    /* per-batch overview: total exams + assignments per batch */
    const byBatch = {};
    examDocs.forEach((e) => {
      const b = e.batch || 'Unspecified';
      byBatch[b] = byBatch[b] || { batch: b, exams: 0, assignments: 0 };
      byBatch[b].exams += 1;
      byBatch[b].assignments += map.get(String(e._id)) || 0;
    });
    const byType = {
      Mid: examDocs.filter((e) => e.examType === 'Mid').length,
      Final: examDocs.filter((e) => e.examType === 'Final').length,
    };

    res.json({
      exams: examDocs.length, invigilators, assignments, required, filled, fullyAssigned,
      byBatch: Object.values(byBatch).sort((a, b) => a.batch.localeCompare(b.batch)),
      byType,
    });
  } catch (e) { next(e); }
};

/* POST /api/sample - one-click demo data */
const SAMPLE_EXAMS = [
  ['CSE2013', 'Data Structures & Algorithms', 'Sec-A', '2nd Year 1st Semester', 'Final', '2026-11-16', '08:00', '10:00', 'Room 201', 48, 2],
  ['ECE2101', 'Signals & Systems', 'Sec-A', '2nd Year 1st Semester', 'Final', '2026-11-16', '10:30', '12:30', 'Room 202', 42, 1],
  ['MATH2011', 'Applied Mathematics I', 'Sec-B', '3rd Year 1st Semester', 'Mid', '2026-11-17', '08:00', '09:30', 'Hall A', 55, 2],
  ['CSE3051', 'Database Systems', 'Sec-A', '3rd Year 1st Semester', 'Final', '2026-11-18', '14:00', '16:00', 'Lab 1', 40, 2],
  ['ECE3204', 'Microprocessors', 'Sec-A', '4th Year 1st Semester', 'Final', '2026-11-19', '08:00', '10:00', 'Room 201', 38, 1],
  ['CSE4075', 'Software Engineering', 'Sec-A', '4th Year 2nd Semester', 'Mid', '2026-11-20', '10:30', '12:00', 'Hall B', 50, 2],
];
const SAMPLE_INVIGILATORS = [
  ['Alemu Bekele', 'DDU/STF/2101', 'CSE', 4],
  ['Hanna Tesfaye', 'DDU/STF/2102', 'ECE', 4],
  ['Kebede Worku', 'DDU/STF/2103', 'CSE', 3],
  ['Selam Tadesse', 'DDU/STF/2104', 'Math', 4],
  ['Dawit Alemu', 'DDU/STF/2105', 'ECE', 3],
  ['Meron Girma', 'DDU/STF/2106', 'CSE', 4],
  ['Yonas Haile', 'DDU/STF/2107', 'CIV', 3],
  ['Tigist Assefa', 'DDU/STF/2108', 'Math', 4],
];

exports.loadSample = async (req, res, next) => {
  try {
    const [e, i] = await Promise.all([Exam.countDocuments({}), Invigilator.countDocuments({})]);
    if (e > 0 || i > 0) {
      return res.status(400).json({ message: 'Data already exists. Delete it first to load sample data.' });
    }
    await Exam.insertMany(SAMPLE_EXAMS.map((x) => ({
      courseCode: x[0], courseTitle: x[1], section: x[2], batch: x[3], examType: x[4],
      date: x[5], startTime: x[6], endTime: x[7], venue: x[8],
      studentsCount: x[9], requiredInvigilators: x[10],
    })));
    await Invigilator.insertMany(SAMPLE_INVIGILATORS.map((x) => ({
      name: x[0], staffId: x[1], department: x[2], maxLoad: x[3], active: true,
    })));
    res.json({ ok: true, exams: SAMPLE_EXAMS.length, invigilators: SAMPLE_INVIGILATORS.length });
  } catch (e) { next(e); }
};
