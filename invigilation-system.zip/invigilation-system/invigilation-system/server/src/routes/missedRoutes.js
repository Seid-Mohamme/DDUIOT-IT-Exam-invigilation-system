const router = require('express').Router();
const c = require('../controllers/missedController');
const { requireAuth, requireAdmin, requireStaff } = require('../middleware/auth');

router.get('/', requireAuth, requireStaff, c.list);      // staff: all absence records
router.post('/', requireAuth, requireStaff, c.record);   // coordinator/admin record an absence
router.get('/mine', requireAuth, c.mine);                // invigilator: own records
router.post('/:id/excuse', requireAuth, c.excuse);       // invigilator: why they missed
router.put('/:id/action', requireAuth, requireAdmin, c.takeAction);  // Department Head measure
router.delete('/:id', requireAuth, requireAdmin, c.remove);

module.exports = router;
