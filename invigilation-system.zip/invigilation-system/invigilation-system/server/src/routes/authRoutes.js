const router = require('express').Router();
const c = require('../controllers/authController');
const { requireAuth, requireAdmin } = require('../middleware/auth');

router.post('/login', c.login);                 // public
router.get('/me', requireAuth, c.me);           // restore session
router.get('/users', requireAuth, requireAdmin, c.listUsers);
router.post('/users', requireAuth, requireAdmin, c.createUser);
router.put('/users/:id', requireAuth, requireAdmin, c.updateUser);          // rename / role / enable-disable
router.put('/users/:id/password', requireAuth, requireAdmin, c.resetPassword);
router.delete('/users/:id', requireAuth, requireAdmin, c.removeUser);

module.exports = router;
