const router = require('express').Router();
const c = require('../controllers/statsController');
const { requireAuth, requireStaff } = require('../middleware/auth');

router.get('/stats/summary', requireAuth, c.summary);
router.post('/sample', requireAuth, requireStaff, c.loadSample);

module.exports = router;
