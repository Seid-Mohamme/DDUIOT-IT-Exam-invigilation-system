const router = require('express').Router();
const c = require('../controllers/assignmentController');
const { requireAuth, requireStaff } = require('../middleware/auth');

router.get('/', requireAuth, requireStaff, c.list);      // full list: staff only (Department Head or Exam Coordinator)
router.get('/mine', requireAuth, c.mine);                // invigilator: own exams
router.post('/', requireAuth, requireStaff, c.create);
router.post('/auto', requireAuth, requireStaff, c.auto);
router.put('/:id', requireAuth, requireStaff, c.update); // fix a wrong assignment
router.patch('/:id', requireAuth, requireStaff, c.setStatus);
router.patch('/:id/checkin', requireAuth, c.checkIn);            // invigilator: "I am in the exam room"
router.patch('/:id/confirm-safe', requireAuth, c.confirmSafe);  // invigilator: "exam is running safely"
router.delete('/', requireAuth, requireStaff, c.removeAll);
router.delete('/:id', requireAuth, requireStaff, c.remove);

module.exports = router;
