const router = require('express').Router();
const c = require('../controllers/notificationController');
const { requireAuth } = require('../middleware/auth');

router.get('/', requireAuth, c.list);        // my notifications + reminders
router.post('/read', requireAuth, c.markRead);  // mark as read

module.exports = router;
