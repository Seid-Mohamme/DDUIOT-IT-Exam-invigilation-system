const router = require('express').Router();
const c = require('../controllers/invigilatorController');
const { requireAuth, requireStaff } = require('../middleware/auth');

router.get('/', requireAuth, c.list);
router.post('/', requireAuth, requireStaff, c.create);
router.post('/import', requireAuth, requireStaff, c.importInvigilators);
router.put('/:id', requireAuth, requireStaff, c.update);
router.delete('/', requireAuth, requireStaff, c.removeAll);
router.delete('/:id', requireAuth, requireStaff, c.remove);

module.exports = router;
