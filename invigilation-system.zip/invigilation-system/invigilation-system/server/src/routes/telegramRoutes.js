const router = require('express').Router();
const c = require('../controllers/telegramController');
const { requireAuth, requireAdmin } = require('../middleware/auth');

router.get('/settings', requireAuth, requireAdmin, c.getSettings);
router.put('/settings', requireAuth, requireAdmin, c.saveSettings);
router.post('/test', requireAuth, requireAdmin, c.test);
router.post('/send-text', requireAuth, requireAdmin, c.sendText);
router.post('/send-file', requireAuth, requireAdmin, c.sendFile);

module.exports = router;
