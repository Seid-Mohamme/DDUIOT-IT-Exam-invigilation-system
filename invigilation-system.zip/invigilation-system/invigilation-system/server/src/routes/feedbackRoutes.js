const router = require('express').Router();
const c = require('../controllers/feedbackController');
const { requireAuth } = require('../middleware/auth');

router.get('/', requireAuth, c.list);        // staff: all feedback
router.post('/', requireAuth, c.submit);     // invigilator: send feedback
router.get('/mine', requireAuth, c.mine);    // invigilator: own feedback

module.exports = router;
