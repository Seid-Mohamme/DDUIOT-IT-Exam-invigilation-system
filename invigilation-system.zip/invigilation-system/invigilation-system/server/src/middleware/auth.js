/* JWT authentication middleware */
const jwt = require('jsonwebtoken');

const JWT_SECRET = process.env.JWT_SECRET || 'ddu-it-invigilation-secret-2026';

const signToken = (user) => jwt.sign(
  {
    id: user._id || user.id,
    role: user.role,
    name: user.name,
    /* user.invigilator can be a raw ObjectId OR a populated document
       (login populates it) - always store the plain id in the token */
    invigilatorId: user.invigilator ? (user.invigilator._id || user.invigilator) : null,
  },
  JWT_SECRET,
  { expiresIn: '7d' }
);

/* every logged-in user (admin or invigilator) */
function requireAuth(req, res, next) {
  const h = req.headers.authorization || '';
  const token = h.startsWith('Bearer ') ? h.slice(7) : null;
  if (!token) return res.status(401).json({ message: 'Please login first' });
  try {
    req.user = jwt.verify(token, JWT_SECRET);
  } catch {
    return res.status(401).json({ message: 'Session expired - please login again' });
  }
  next();
}

/* Main admin only (Department Head account) - user accounts & Telegram */
function requireAdmin(req, res, next) {
  if (!req.user || req.user.role !== 'admin') {
    return res.status(403).json({ message: 'Only the main admin can do this' });
  }
  next();
}

/* Staff = main admin (Department Head) OR exam coordinator.
   They manage exams, invigilators and assignments; user accounts stay admin-only. */
function requireStaff(req, res, next) {
  if (!req.user || !['admin', 'coordinator'].includes(req.user.role)) {
    return res.status(403).json({ message: 'Only the Department Head or Exam Coordinator can do this' });
  }
  next();
}

module.exports = { signToken, requireAuth, requireAdmin, requireStaff, JWT_SECRET };
