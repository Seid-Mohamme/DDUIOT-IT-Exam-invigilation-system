/* Assignment engine: manual assignment with clash validation,
   batch-balanced auto-assignment (different batches on different days)
   and fair load distribution */
const Exam = require('../models/Exam');
const Invigilator = require('../models/Invigilator');
const Assignment = require('../models/Assignment');
const { clash } = require('../utils/timeUtils');

const fail = (status, message) => { const e = new Error(message); e.status = status; return e; };

/* ONE clear warning message used everywhere an invigilator is double-booked:
   "X is already assigned at that date & time ..." */
const clashMsg = (invName, clashExam) =>
  `ALREADY ASSIGNED AT THAT TIME: ${invName} already invigilates ` +
  `${clashExam.courseCode} on ${clashExam.date} (${clashExam.startTime}-${clashExam.endTime}` +
  `${clashExam.venue ? ', ' + clashExam.venue : ''}). ` +
  `Pick a free invigilator instead - the "Suggest" button lists free recommendations.`;

/* Assign one invigilator to one exam (validates duplicates + time clashes) */
async function assignInvigilator(examId, invigilatorId) {
  const exam = await Exam.findById(examId);
  const inv = await Invigilator.findById(invigilatorId);
  if (!exam || !inv) throw fail(404, 'Exam or invigilator not found');
  if (!inv.active) throw fail(400, `${inv.name} is marked inactive`);

  const dup = await Assignment.findOne({ exam: exam._id, invigilator: inv._id });
  if (dup) throw fail(400, `${inv.name} is already assigned to this exam`);

  const others = await Assignment.find({ invigilator: inv._id }).populate('exam');
  const c = others.find((a) => a.exam &&
    clash(exam.date, exam.startTime, exam.endTime, a.exam.date, a.exam.startTime, a.exam.endTime));
  if (c) {
    throw fail(400, clashMsg(inv.name, c.exam));
  }

  const count = await Assignment.countDocuments({ exam: exam._id });
  return Assignment.create({
    exam: exam._id, invigilator: inv._id, role: count === 0 ? 'Instructor' : 'Member',
  });
}

/* Change a wrong assignment: replace the invigilator and/or the role.
   Validates the new invigilator exactly like a fresh assignment. */
async function updateAssignment(assignmentId, { invigilatorId, role }) {
  const a = await Assignment.findById(assignmentId);
  if (!a) throw fail(404, 'Assignment not found');

  const newRole = role || a.role;
  if (!['Instructor', 'Member'].includes(newRole)) {
    throw fail(400, 'Role must be Instructor or Member');
  }

  const targetInv = invigilatorId || String(a.invigilator);
  const changing = String(a.invigilator) !== String(targetInv);

  if (changing) {
    const inv = await Invigilator.findById(targetInv);
    if (!inv) throw fail(404, 'New invigilator not found');
    if (!inv.active) throw fail(400, `${inv.name} is marked inactive`);

    const dup = await Assignment.findOne({ exam: a.exam, invigilator: inv._id });
    if (dup) throw fail(400, `${inv.name} is already assigned to this exam`);

    const exam = await Exam.findById(a.exam);
    const others = await Assignment.find({ invigilator: inv._id, _id: { $ne: a._id } }).populate('exam');
    const c = others.find((o) => o.exam &&
      clash(exam.date, exam.startTime, exam.endTime, o.exam.date, o.exam.startTime, o.exam.endTime));
    if (c) {
      throw fail(400, clashMsg(inv.name, c.exam));
    }
    a.invigilator = inv._id;
  }

  a.role = newRole;
  await a.save();
  await a.populate(['exam', 'invigilator']);
  return a;
}

/* AUTO-ASSIGNMENT ENGINE
   For every exam (sorted by date/time) fill free slots with the least-loaded
   available invigilators. Never removes existing assignments. Respects
   maxLoad and rejects time clashes.

   BATCH BALANCING: when two invigilators have the same load, the one who has
   covered this exam's batch FEWER times wins - so across the exam days every
   invigilator rotates through DIFFERENT batches (2nd/3rd/4th year ...)       */
async function autoAssign() {
  const exams = await Exam.find({}).sort({ date: 1, startTime: 1, courseCode: 1 }).lean();
  const invs = await Invigilator.find({ active: true }).lean();
  const existing = await Assignment.find({}).populate('exam').lean();

  const load = {};      // invId -> total assignments
  const busy = {};      // invId -> [{ date, s, e }] occupied times
  const batchCount = {};// invId -> { batch: n }  how often each batch was covered
  existing.filter((a) => a.exam && a.invigilator).forEach((a) => {
    const k = String(a.invigilator._id);
    load[k] = (load[k] || 0) + 1;
    (busy[k] = busy[k] || []).push({ date: a.exam.date, s: a.exam.startTime, e: a.exam.endTime });
    if (a.exam.batch) {
      batchCount[k] = batchCount[k] || {};
      batchCount[k][a.exam.batch] = (batchCount[k][a.exam.batch] || 0) + 1;
    }
  });

  const timesSameBatch = (k, exam) =>
    (exam.batch && batchCount[k]) ? (batchCount[k][exam.batch] || 0) : 0;

  const toCreate = [];
  const unfulfilled = [];

  for (const exam of exams) {
    const have = existing.filter((a) => a.exam && String(a.exam._id) === String(exam._id)).length;
    const need = Math.max(0, (exam.requiredInvigilators || 1) - have);
    let took = 0;

    for (let k = 0; k < need; k++) {
      const pool = invs
        .filter((v) => (load[String(v._id)] || 0) < (v.maxLoad || 4))
        .filter((v) => !(busy[String(v._id)] || []).some((b) =>
          clash(exam.date, exam.startTime, exam.endTime, b.date, b.s, b.e)))
        .sort((a, b) => (load[String(a._id)] || 0) - (load[String(b._id)] || 0)
          || timesSameBatch(String(a._id), exam) - timesSameBatch(String(b._id), exam)
          || String(a.name).localeCompare(String(b.name)));
      if (!pool.length) break;
      const v = pool[0];
      toCreate.push({
        exam: exam._id, invigilator: v._id,
        role: have === 0 && k === 0 ? 'Instructor' : 'Member',
        status: 'Assigned',
      });
      load[String(v._id)] = (load[String(v._id)] || 0) + 1;
      (busy[String(v._id)] = busy[String(v._id)] || []).push({
        date: exam.date, s: exam.startTime, e: exam.endTime,
      });
      if (exam.batch) {
        batchCount[String(v._id)] = batchCount[String(v._id)] || {};
        batchCount[String(v._id)][exam.batch] =
          (batchCount[String(v._id)][exam.batch] || 0) + 1;
      }
      took++;
    }
    if (took < need) {
      unfulfilled.push({ courseCode: exam.courseCode, date: exam.date, missing: need - took });
    }
  }

  if (toCreate.length) await Assignment.insertMany(toCreate);
  return { assigned: toCreate.length, unfulfilled };
}

module.exports = { assignInvigilator, autoAssign, updateAssignment };
