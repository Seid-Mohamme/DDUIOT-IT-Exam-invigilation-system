/* =====================================================================
   DDU-IT Invigilation System - BACKEND entry point
   MongoDB: invigilation_system   |   API port: 5050
   ===================================================================== */
const mongoose = require('mongoose');
const app = require('./src/app');

const MONGO_URI = process.env.MONGO_URI || 'mongodb://127.0.0.1:27017/invigilation_system';
const PORT = process.env.PORT || 5050;

mongoose
  .connect(MONGO_URI, { serverSelectionTimeoutMS: 8000 })
  .then(() => {
    console.log('[OK] MongoDB connected:', MONGO_URI);
    app.listen(PORT, () =>
      console.log(`[OK] API server running -> http://localhost:${PORT}`));
  })
  .catch((e) => {
    console.error('[X] MongoDB connection failed:', e.message);
    console.error('    Start MongoDB first (net start MongoDB), then run: npm run dev');
    process.exit(1);
  });
