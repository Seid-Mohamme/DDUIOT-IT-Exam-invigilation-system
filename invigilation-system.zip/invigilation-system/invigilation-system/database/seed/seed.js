/* =====================================================================
   Database seeder - sample exams + invigilators + login accounts
   Run from the project root:   npm run seed
   ===================================================================== */
const path = require('path');
const { createRequire } = require('module');

/* resolve mongoose + bcrypt from server/node_modules */
const reqServer = createRequire(path.join(__dirname, '..', '..', 'server', 'package.json'));
const mongoose = reqServer('mongoose');
const bcrypt = reqServer('bcryptjs');

/* reuse the real backend models */
const Exam = require(path.join(__dirname, '..', '..', 'server', 'src', 'models', 'Exam'));
const Invigilator = require(path.join(__dirname, '..', '..', 'server', 'src', 'models', 'Invigilator'));
const Assignment = require(path.join(__dirname, '..', '..', 'server', 'src', 'models', 'Assignment'));
const User = require(path.join(__dirname, '..', '..', 'server', 'src', 'models', 'User'));

const MONGO_URI = process.env.MONGO_URI || 'mongodb://127.0.0.1:27017/invigilation_system';

const EXAMS = [
  ['CSE2013', 'Data Structures & Algorithms', 'Sec-A', '2nd Year 1st Semester', 'Final', '2026-11-16', '08:00', '10:00', 'Room 201', 48, 2],
  ['ECE2101', 'Signals & Systems', 'Sec-A', '2nd Year 1st Semester', 'Final', '2026-11-16', '10:30', '12:30', 'Room 202', 42, 1],
  ['MATH2011', 'Applied Mathematics I', 'Sec-B', '3rd Year 1st Semester', 'Mid', '2026-11-17', '08:00', '09:30', 'Hall A', 55, 2],
  ['CSE3051', 'Database Systems', 'Sec-A', '3rd Year 1st Semester', 'Final', '2026-11-18', '14:00', '16:00', 'Lab 1', 40, 2],
  ['ECE3204', 'Microprocessors', 'Sec-A', '4th Year 1st Semester', 'Final', '2026-11-19', '08:00', '10:00', 'Room 201', 38, 1],
  ['CSE4075', 'Software Engineering', 'Sec-A', '4th Year 2nd Semester', 'Mid', '2026-11-20', '10:30', '12:00', 'Hall B', 50, 2],
];
const INVIGILATORS = [
  ['Alemu Bekele', 'DDU/STF/2101', 'CSE', 4],
  ['Hanna Tesfaye', 'DDU/STF/2102', 'ECE', 4],
  ['Kebede Worku', 'DDU/STF/2103', 'CSE', 3],
  ['Selam Tadesse', 'DDU/STF/2104', 'Math', 4],
  ['Dawit Alemu', 'DDU/STF/2105', 'ECE', 3],
  ['Meron Girma', 'DDU/STF/2106', 'CSE', 4],
  ['Yonas Haile', 'DDU/STF/2107', 'CIV', 3],
  ['Tigist Assefa', 'DDU/STF/2108', 'Math', 4],
];

(async () => {
  try {
    await mongoose.connect(MONGO_URI, { serverSelectionTimeoutMS: 8000 });
    console.log('[OK] Connected:', MONGO_URI);

    await Promise.all([
      Assignment.deleteMany({}),
      Exam.deleteMany({}),
      Invigilator.deleteMany({}),
      User.deleteMany({}),
    ]);

    await Exam.insertMany(EXAMS.map((x) => ({
      courseCode: x[0], courseTitle: x[1], section: x[2], batch: x[3], examType: x[4],
      date: x[5], startTime: x[6], endTime: x[7], venue: x[8],
      studentsCount: x[9], requiredInvigilators: x[10],
    })));
    const invs = await Invigilator.insertMany(INVIGILATORS.map((x) => ({
      name: x[0], staffId: x[1], department: x[2], maxLoad: x[3], active: true,
    })));

    /* ---- login accounts ---- */
    await User.create({
      name: 'Admin',
      email: 'admin@ddu.edu.et',
      passwordHash: await bcrypt.hash('admin@123', 10),
      role: 'admin',
    });
    await User.create({
      name: 'Exam Coordinator',
      email: 'coordinator@ddu.edu.et',
      passwordHash: await bcrypt.hash('coord@123', 10),
      role: 'coordinator',
    });
    await User.create({
      name: invs[0].name,
      email: 'instructor@ddu.edu.et',
      passwordHash: await bcrypt.hash('invig@123', 10),
      role: 'invigilator',
      invigilator: invs[0]._id,
    });

    console.log(`[OK] Seeded ${EXAMS.length} exams and ${INVIGILATORS.length} invigilators`);
    console.log('[OK] Logins -> Admin (Department Head): admin@ddu.edu.et / admin@123');
    console.log('            Exam Coordinator demo: coordinator@ddu.edu.et / coord@123');
    console.log('            Invigilator demo:      instructor@ddu.edu.et / invig@123');
    console.log('     Open http://localhost:5174, login as admin, click "Auto-assign invigilators"');
    await mongoose.disconnect();
    process.exit(0);
  } catch (e) {
    console.error('[X] Seed failed:', e.message);
    console.error('    Is MongoDB running? (net start MongoDB)');
    process.exit(1);
  }
})();
